# Center El Gowaily — سنتر الجويلي

A bilingual (Arabic RTL / English LTR) clothing-store customer application and admin workspace, built with React, TypeScript, Vite, and a Supabase-ready data layer. Prices and checkout totals are denominated in Egyptian pounds (EGP).

> **Local preview note:** With no Supabase URL/key configured, the app runs against an isolated local demo adapter. Demo catalogue, customer accounts, cart, settings, and created orders live in this browser's `localStorage` only. This is for reviewing UX and exercising flows—not production authentication, persistence, inventory, or authorization. Once Supabase is configured, the application uses Supabase and its RLS policies.

## What is included

- Customer storefront: home, dynamic categories, shop/search, product details, variant-aware size/colour selection, stock checks, related products, cart page and slide-in bag drawer.
- Checkout wizard with customer/contact/address validation, delivery estimates, cash/card-on-delivery choices, confirmation, and phone-verified order tracking.
- Arabic/English switching without discarding cart or session; logical CSS layout supports RTL/LTR.
- Customer registration, sign-in, email verification result, password reset, profile, order history and order details.
- Responsive admin login/dashboard, product editor (including image upload, optional variants and variant inventory), category manager, inventory, sizes/colours, orders/status updates, customer list, store settings and promotions.
- Loading skeletons, retryable error states, empty states, toast feedback, modal/drawer close behavior, responsive navigation and accessible labels/focus states.
- Locally bundled fashion campaign/product placeholder images, image fallback, PWA manifest and a minimal offline navigation fallback.
- `supabase/schema.sql`: starting Supabase schema, indexes, role protection, RLS policies, Storage policies and transactional checkout/tracking/product-save RPCs.

## Run locally

Requirements: Node.js 20.19+ (or 22.12+) and npm; Vite 8 uses these minimum versions.

```bash
npm install
cp .env.example .env
npm run dev
```

Vite serves at `http://localhost:5173` by default.

### Local demo access

When Supabase variables are blank, local demo mode turns on automatically. The demo-only admin credentials are configurable in `.env`:

```text
Email:    admin@centerelgowaily.demo
Password: CenterDemo!2026
```

Open `/admin/login` to access the local admin workspace. Customer registration also works locally. Demo credentials and the local adapter are **not secure and must not be used for a live store**. Product and category examples are isolated in `src/data/demoSeed.ts`; demo orders are created only by going through checkout and are not seeded.

To reset the local preview, clear the site's local storage keys beginning with `ceg.`.

## Connect Supabase

1. Create a Supabase project.
2. Apply `supabase/schema.sql` in the Supabase SQL Editor. The schema creates the catalog, variant inventory, profiles, customer addresses, orders and order events; enables RLS; creates the `product-images` public bucket; and adds RPCs for product saving, order placement and phone-verified tracking.
3. Copy the project's **Project URL** and **anon/public key** into `.env`:

   ```env
   VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
   VITE_USE_DEMO_DATA=false
   ```

   Never set a `service_role` key in a `VITE_` variable. Vite variables are visible to every browser user.
4. In Supabase Auth, set the local Site URL and allow these redirect URLs:
   - `http://localhost:5173/auth/verify`
   - `http://localhost:5173/password/reset`
   - Add your production domain equivalents before deployment.
5. Register a customer account, verify it, then promote the intended admin from the SQL Editor:

   ```sql
   update public.profiles
   set role = 'admin'
   where email = 'your-admin@example.com';
   ```

   The sign-up flow always creates `customer` profiles. The browser cannot grant itself an admin role; the database trigger and RLS policies enforce this.
6. Restart Vite after changing `.env`. Create categories and products from `/admin` or insert your reviewed catalogue through your chosen database workflow.

The database schema is a **starter integration contract**, not a claim that the final production schema has been approved. Review the SQL and adapt naming/relationships to the database files you plan to provide. The browser submits only product/variant IDs and quantities; `place_order` locks and validates inventory, reloads prices, and calculates subtotal, delivery fee and total in Postgres.

## Important integration boundaries

- UI pages call functions in `src/services/repository.ts`; they do not import seed objects. The repository selects the demo adapter only when no usable Supabase credentials are present (or when explicitly forced for local testing).
- `src/services/supabase.ts` is the only client factory. Only the public anon key is accepted there.
- Authentication lives in `src/contexts/AuthContext.tsx` and the database `profiles` table. Role checks in React improve navigation UX; database RLS remains authoritative.
- `place_order` computes every order line from current product/variant prices and stock, and calculates delivery server-side using the `general` store setting (`deliveryFee`, `freeDeliveryThreshold`). Never replace this with browser-submitted totals.
- `track_order` requires both order number and the phone used at checkout. Customers can query only their own order rows through authenticated RLS; unauthenticated tracking uses this phone-verified RPC.
- Product image uploads in Supabase use the `product-images` bucket. Demo mode stores data URLs locally, so it is for small preview images only.
- Online card processing, courier/label integrations, final delivery rules, transactional email and operational rate limiting are intentionally not fabricated. Payment choices are cash/card on delivery until a gateway is chosen.

## Routes

### Customer

`/` · `/shop` · `/search?q=…` · `/category/:slug` · `/product/:slug` · `/cart` · `/checkout` · `/order-success/:orderNumber` · `/track` · `/track/:orderNumber` · `/login` · `/register` · `/forgot-password` · `/password/reset` · `/auth/verify` · `/account` · `/orders` · `/orders/:id` · `/about` · `/help`

### Admin

`/admin/login` · `/admin` · `/admin/products` · `/admin/products/new` · `/admin/products/:id/edit` · `/admin/categories` · `/admin/inventory` · `/admin/attributes` · `/admin/orders` · `/admin/customers` · `/admin/settings`

## Project structure

```text
public/
  icons/icon.svg
  images/                 # Generated, local campaign/product placeholders + fallback
  manifest.webmanifest
  offline.html
  sw.js
src/
  components/
    cart/                  # Bag drawer
    layout/                # Store header/footer and admin shell
    product/               # Product cards and grids
    ui/                    # Accessible reusable controls/states/dialogs
  contexts/                # Locale, auth, cart and toast state
  data/demoSeed.ts         # Local-only adapter seed, not used with Supabase
  hooks/                   # Async data + document metadata
  i18n/messages.ts         # Arabic and English UI copy
  pages/customer/          # Storefront, auth, checkout, account and order flows
  pages/admin/             # Dashboard and catalogue operations
  services/                # Supabase client + repository/data boundary
  styles/global.css
  types/index.ts
  utils/
supabase/schema.sql
```

## Quality checks

```bash
npm run typecheck
npm run build
npm run preview
```

The build is client-side and can be hosted on any static host that supports SPA fallback to `index.html`. Configure the host's fallback rule and Supabase redirect URLs for the production domain. Keep `.env` out of version control.
