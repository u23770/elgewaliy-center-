import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpLeft, ShoppingBag, Trash2, X } from 'lucide-react';
import { useCart } from '../../contexts/CartContext';
import { useLocale } from '../../contexts/LocaleContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { getDeliveryEstimate, getStoreSettings } from '../../services/repository';
import { Button, EmptyState, IconButton, QuantityStepper } from '../ui/primitives';

export function CartDrawer() {
  const { drawerOpen, closeDrawer, lines, subtotal, setQuantity, removeItem, isLoading } = useCart();
  const { t, localized, formatPrice, dir } = useLocale();
  const { data: settings } = useAsyncData(getStoreSettings, []);
  useEffect(() => {
    if (!drawerOpen) return;
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') closeDrawer(); };
    document.addEventListener('keydown', close); document.body.classList.add('drawer-open');
    return () => { document.removeEventListener('keydown', close); document.body.classList.remove('drawer-open'); };
  }, [drawerOpen, closeDrawer]);
  const delivery = settings ? getDeliveryEstimate(subtotal, settings) : null;
  return <div className={`drawer-backdrop ${drawerOpen ? 'is-open' : ''}`} aria-hidden={!drawerOpen} onMouseDown={event => { if (event.target === event.currentTarget) closeDrawer(); }}>
    <aside className={`cart-drawer ${drawerOpen ? 'is-open' : ''}`} role="dialog" aria-modal="true" aria-labelledby="cart-drawer-title" dir={dir}>
      <div className="drawer-header"><div><div className="eyebrow">{t('cart')}</div><h2 id="cart-drawer-title">{t('orderSummary')} <span className="drawer-count">{lines.reduce((sum, item) => sum + item.quantity, 0)}</span></h2></div><IconButton label={t('close')} onClick={closeDrawer}><X size={20} /></IconButton></div>
      <div className="drawer-body">
        {isLoading && !lines.length ? <div className="drawer-loading"><span className="skeleton skeleton-line" /><span className="skeleton skeleton-line" /><span className="skeleton skeleton-line medium" /></div> : null}
        {!isLoading && !lines.length ? <EmptyState icon={<ShoppingBag size={24} />} title={t('emptyBag')} description={t('emptyBagBody')} action={<Button onClick={closeDrawer}>{t('browsePieces')}</Button>} /> : null}
        {lines.map(line => <article className="drawer-line" key={`${line.productId}-${line.variantId ?? 'simple'}`}>
          <Link to={`/product/${line.product.slug}`} onClick={closeDrawer} className="drawer-line-image"><img src={line.variant?.imageUrl ?? line.product.images[0]?.url ?? '/images/fallback.svg'} alt={localized(line.product.name)} /></Link>
          <div className="drawer-line-info"><Link to={`/product/${line.product.slug}`} onClick={closeDrawer} className="drawer-line-name">{localized(line.product.name)}</Link>
            <div className="drawer-line-variant">{line.variant?.size ? <span>{t('size')}: {line.variant.size}</span> : null}{line.variant?.color ? <span>{t('color')}: {localized(line.variant.color.name)}</span> : null}</div>
            <strong>{formatPrice(line.unitPrice)}</strong>
            <div className="drawer-line-controls"><QuantityStepper value={line.quantity} max={line.maxQuantity} onChange={value => setQuantity(line.productId, line.variantId, value)} label={t('quantity')} /><button className="text-action danger-text" type="button" onClick={() => removeItem(line.productId, line.variantId)}><Trash2 size={14} />{t('remove')}</button></div>
          </div>
        </article>)}
      </div>
      {lines.length ? <div className="drawer-footer"><div className="summary-row"><span>{t('subtotal')}</span><strong>{formatPrice(subtotal)}</strong></div><div className="summary-row"><span>{t('delivery')}</span><span>{delivery === null ? t('deliveryAtCheckout') : delivery === 0 ? t('free') : formatPrice(delivery)}</span></div><p className="drawer-note">{t('deliveryFeeNote')}</p><div className="drawer-buttons"><Link to="/checkout" onClick={closeDrawer}><Button size="lg" className="full-width">{t('checkout')} <ArrowUpLeft size={17} /></Button></Link><Link to="/cart" onClick={closeDrawer} className="continue-link">{t('viewAll')}</Link></div></div> : null}
    </aside>
  </div>;
}
