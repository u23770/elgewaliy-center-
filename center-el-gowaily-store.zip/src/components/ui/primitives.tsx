import { useEffect, useRef, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react';
import { AlertTriangle, ArrowLeft, ArrowRight, LoaderCircle, Minus, Plus, PackageOpen, X } from 'lucide-react';
import type { OrderStatus } from '../../types';
import { useLocale } from '../../contexts/LocaleContext';
import { statusLabel } from '../../utils/format';

export function Button({ children, variant = 'primary', size = 'md', loading = false, className = '', disabled, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'dark'; size?: 'sm' | 'md' | 'lg'; loading?: boolean }) {
  return <button className={`button button-${variant} button-${size} ${className}`} disabled={disabled || loading} {...props}>
    {loading ? <LoaderCircle className="spin" size={17} aria-hidden="true" /> : null}{children}
  </button>;
}

export function IconButton({ label, children, className = '', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return <button className={`icon-button ${className}`} aria-label={label} title={label} {...props}>{children}</button>;
}

export function TextField({ label, error, hint, id, className = '', ...props }: InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string; hint?: string }) {
  const generated = id ?? `field-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
  return <div className={`field ${className}`}>
    <label className="field-label" htmlFor={generated}>{label}{props.required ? <span className="required-dot"> *</span> : null}</label>
    <input id={generated} className={`text-input ${error ? 'input-error' : ''}`} aria-invalid={Boolean(error)} aria-describedby={error ? `${generated}-error` : hint ? `${generated}-hint` : undefined} {...props} />
    {error ? <span id={`${generated}-error`} className="field-error" role="alert">{error}</span> : hint ? <span id={`${generated}-hint`} className="field-hint">{hint}</span> : null}
  </div>;
}

export function TextAreaField({ label, error, id, className = '', ...props }: TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string; error?: string }) {
  const generated = id ?? `field-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
  return <div className={`field ${className}`}>
    <label className="field-label" htmlFor={generated}>{label}{props.required ? <span className="required-dot"> *</span> : null}</label>
    <textarea id={generated} className={`text-input text-area ${error ? 'input-error' : ''}`} aria-invalid={Boolean(error)} aria-describedby={error ? `${generated}-error` : undefined} {...props} />
    {error ? <span id={`${generated}-error`} className="field-error" role="alert">{error}</span> : null}
  </div>;
}

export function SelectField({ label, id, children, error, className = '', ...props }: React.SelectHTMLAttributes<HTMLSelectElement> & { label: string; error?: string }) {
  const generated = id ?? `field-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
  return <div className={`field ${className}`}>
    <label className="field-label" htmlFor={generated}>{label}{props.required ? <span className="required-dot"> *</span> : null}</label>
    <select id={generated} className={`text-input select-input ${error ? 'input-error' : ''}`} aria-invalid={Boolean(error)} aria-describedby={error ? `${generated}-error` : undefined} {...props}>{children}</select>
    {error ? <span id={`${generated}-error`} className="field-error" role="alert">{error}</span> : null}
  </div>;
}

export function PageHeader({ eyebrow, title, description, actions, className = '' }: { eyebrow?: string; title: string; description?: string; actions?: ReactNode; className?: string }) {
  return <div className={`page-header ${className}`}>
    <div>{eyebrow ? <div className="eyebrow">{eyebrow}</div> : null}<h1>{title}</h1>{description ? <p>{description}</p> : null}</div>
    {actions ? <div className="page-header-actions">{actions}</div> : null}
  </div>;
}

export function SectionHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="section-heading">
    <div>{eyebrow ? <div className="eyebrow">{eyebrow}</div> : null}<h2>{title}</h2>{description ? <p>{description}</p> : null}</div>
    {action ? <div className="section-heading-action">{action}</div> : null}
  </div>;
}

export function Spinner({ label, size = 'lg' }: { label?: string; size?: 'sm' | 'lg' }) {
  return <div className={`loading-state loading-${size}`} role="status"><LoaderCircle className="spin" size={size === 'lg' ? 26 : 18} /><span>{label ?? 'Loading'}</span></div>;
}

export function SkeletonCard() {
  return <div className="product-card skeleton-card" aria-hidden="true"><div className="skeleton skeleton-image" /><div className="skeleton-lines"><div className="skeleton skeleton-line short" /><div className="skeleton skeleton-line" /><div className="skeleton skeleton-line medium" /></div></div>;
}

export function ProductGridSkeleton({ count = 8 }: { count?: number }) {
  return <div className="product-grid">{Array.from({ length: count }, (_, index) => <SkeletonCard key={index} />)}</div>;
}

export function EmptyState({ title, description, action, icon }: { title: string; description?: string; action?: ReactNode; icon?: ReactNode }) {
  return <div className="empty-state"><div className="empty-icon">{icon ?? <PackageOpen size={25} />}</div><h2>{title}</h2>{description ? <p>{description}</p> : null}{action ? <div className="empty-action">{action}</div> : null}</div>;
}

export function ErrorState({ title, description, onRetry }: { title: string; description?: string; onRetry?: () => void }) {
  const { t } = useLocale();
  return <div className="error-state"><div className="error-icon"><AlertTriangle size={22} /></div><div><h2>{title}</h2>{description ? <p>{description}</p> : null}</div>{onRetry ? <Button variant="secondary" onClick={onRetry}>{t('retry')}</Button> : null}</div>;
}

export function Modal({ open, onClose, title, children, className = '', labelledBy }: { open: boolean; onClose: () => void; title: string; children: ReactNode; className?: string; labelledBy?: string }) {
  const panelRef = useRef<HTMLDivElement>(null);
  const { t, dir } = useLocale();
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    document.body.classList.add('modal-open');
    window.setTimeout(() => panelRef.current?.focus(), 20);
    return () => { document.removeEventListener('keydown', onKey); document.body.classList.remove('modal-open'); previous?.focus(); };
  }, [open, onClose]);
  if (!open) return null;
  return <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <div className={`modal-panel ${className}`} role="dialog" aria-modal="true" aria-labelledby={labelledBy ?? 'modal-title'} dir={dir} ref={panelRef} tabIndex={-1}>
      <div className="modal-heading"><h2 id={labelledBy ?? 'modal-title'}>{title}</h2><IconButton label={t('close')} onClick={onClose}><X size={19} /></IconButton></div>
      <div className="modal-content">{children}</div>
    </div>
  </div>;
}

export function QuantityStepper({ value, min = 1, max = 99, onChange, label }: { value: number; min?: number; max?: number; onChange: (value: number) => void; label: string }) {
  const { dir } = useLocale();
  return <div className="quantity-stepper" aria-label={label}>
    <button type="button" aria-label={dir === 'rtl' ? 'زيادة الكمية' : 'Increase quantity'} disabled={value >= max} onClick={() => onChange(Math.min(max, value + 1))}><Plus size={14} /></button>
    <span aria-live="polite">{value}</span>
    <button type="button" aria-label={dir === 'rtl' ? 'تقليل الكمية' : 'Decrease quantity'} disabled={value <= min} onClick={() => onChange(Math.max(min, value - 1))}><Minus size={14} /></button>
  </div>;
}

export function OrderStatusBadge({ status }: { status: OrderStatus }) {
  const { locale } = useLocale();
  return <span className={`status-badge status-${status}`}>{statusLabel(status, locale)}</span>;
}

export function DirectionalArrow({ size = 16 }: { size?: number }) {
  const { dir } = useLocale();
  return dir === 'rtl' ? <ArrowLeft size={size} /> : <ArrowRight size={size} />;
}
