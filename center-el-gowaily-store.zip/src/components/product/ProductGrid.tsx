import type { Product } from '../../types';
import { ProductCard } from './ProductCard';
import { ProductGridSkeleton } from '../ui/primitives';

export function ProductGrid({ products, loading = false, skeletonCount = 8 }: { products: Product[]; loading?: boolean; skeletonCount?: number }) {
  if (loading) return <ProductGridSkeleton count={skeletonCount} />;
  if (!products.length) return null;
  return <div className="product-grid">{products.map((product, index) => <ProductCard product={product} index={index} key={product.id} />)}</div>;
}
