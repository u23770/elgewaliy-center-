import { useState } from 'react';
import { ArrowUpLeft, Plus, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Product } from '../../types';
import { useLocale } from '../../contexts/LocaleContext';
import { useCart } from '../../contexts/CartContext';
import { discountPercent } from '../../utils/format';

function StoreImage({ src, alt, className = '' }: { src?: string; alt: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  return <img className={className} src={failed || !src ? '/images/fallback.svg' : src} alt={alt} loading="lazy" onError={() => setFailed(true)} />;
}

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const { localized, formatPrice, t } = useLocale();
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);
  const stock = product.variants.length ? product.variants.reduce((total, variant) => total + (variant.active ? variant.stock : 0), 0) : product.stock;
  const sale = discountPercent(product.price, product.salePrice);
  const image = product.images[0]?.url;
  const quickAdd = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault(); event.stopPropagation();
    if (product.variants.length) return;
    addItem(product, null);
    setAdded(true); window.setTimeout(() => setAdded(false), 1200);
  };
  return <article className="product-card" style={{ animationDelay: `${Math.min(index % 8, 7) * 45}ms` }}>
    <Link to={`/product/${product.slug}`} className="product-card-media" aria-label={localized(product.name)}>
      <StoreImage src={image} alt={localized(product.images[0]?.alt) || localized(product.name)} />
      <div className="product-card-badges">{sale ? <span className="sale-badge">-{sale}%</span> : null}{stock <= 0 ? <span className="soldout-badge">{t('soldOut')}</span> : null}</div>
      <span className="product-card-arrow" aria-hidden="true"><ArrowUpLeft size={17} /></span>
    </Link>
    <div className="product-card-copy">
      <div className="product-card-meta"><span>{localized(product.category)}</span>{stock > 0 && stock <= 5 ? <span className="stock-note">{t('lowStock')}</span> : null}</div>
      <Link to={`/product/${product.slug}`} className="product-card-name">{localized(product.name)}</Link>
      <div className="product-card-price"><strong>{formatPrice(product.salePrice ?? product.price)}</strong>{product.salePrice ? <del>{formatPrice(product.price)}</del> : null}</div>
      <div className="product-card-bottom">
        <div className="product-card-swatches" aria-hidden="true">
          {[...new Map(product.variants.filter(variant => variant.color).map(variant => [variant.color!.key, variant.color!])).values()].slice(0, 4).map(color => <i key={color.key} style={{ backgroundColor: color.hex }} />)}
          {product.variants.some(variant => variant.size) ? <span>{[...new Set(product.variants.map(variant => variant.size).filter(Boolean))].slice(0, 3).join(' · ')}</span> : null}
        </div>
        {product.variants.length ? <Link className="quick-add-link" to={`/product/${product.slug}`} aria-label={t('chooseOptions')}>{t('chooseOptions')}<ArrowUpLeft size={14} /></Link> : <button className="quick-add-button" type="button" disabled={stock <= 0} onClick={quickAdd} aria-label={t('addToBag')}>
          {added ? <ShoppingBag size={16} /> : <Plus size={16} />}<span>{added ? t('addedToBag') : t('addToBag')}</span>
        </button>}
      </div>
    </div>
  </article>;
}
