import { useEffect, useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { BarChart3, Boxes, ClipboardList, Layers3, LogOut, Menu, Package, Palette, Settings2, ShoppingBag, Store, Users, X } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLocale } from '../../contexts/LocaleContext';
import { IconButton } from '../ui/primitives';

export function AdminShell() {
  const { t, toggleLocale, locale } = useLocale(); const { user, signOut, isDemoMode } = useAuth(); const navigate = useNavigate(); const [mobileOpen, setMobileOpen] = useState(false);
  const navItems = [
    { to: '/admin', key: 'dashboard' as const, icon: BarChart3, end: true },
    { to: '/admin/products', key: 'adminProducts' as const, icon: Package },
    { to: '/admin/categories', key: 'adminCategories' as const, icon: Layers3 },
    { to: '/admin/inventory', key: 'inventory' as const, icon: Boxes },
    { to: '/admin/attributes', key: 'attributes' as const, icon: Palette },
    { to: '/admin/orders', key: 'adminOrders' as const, icon: ClipboardList },
    { to: '/admin/customers', key: 'customers' as const, icon: Users },
    { to: '/admin/settings', key: 'settings' as const, icon: Settings2 },
  ];
  useEffect(() => {
    if (!mobileOpen) return;
    const listener = (event: KeyboardEvent) => { if (event.key === 'Escape') setMobileOpen(false); };
    document.addEventListener('keydown', listener); document.body.classList.add('admin-menu-open');
    return () => { document.removeEventListener('keydown', listener); document.body.classList.remove('admin-menu-open'); };
  }, [mobileOpen]);
  const logout = async () => { await signOut(); navigate('/admin/login'); };
  return <div className="admin-shell" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
    <aside className={`admin-sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="admin-brand"><span className="brand-mark"><span>ج</span><i /></span><div><strong>{locale === 'ar' ? 'الجويلي' : 'EL GOWAILY'}</strong><small>{t('admin')}</small></div><IconButton className="admin-mobile-close" label={t('close')} onClick={() => setMobileOpen(false)}><X size={19} /></IconButton></div>
      <div className="admin-sidebar-label">{t('adminDashboard')}</div>
      <nav className="admin-nav" aria-label={t('admin')}>{navItems.map(({ to, key, icon: Icon, end }) => <NavLink key={to} end={end} to={to} onClick={() => setMobileOpen(false)} className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}><Icon size={18} /><span>{t(key)}</span><i /></NavLink>)}</nav>
      <div className="admin-sidebar-footer"><div className="admin-user-mini"><span className="admin-user-avatar">{user?.fullName?.[0] ?? 'A'}</span><div><strong>{user?.fullName || 'Administrator'}</strong><small>{user?.email}</small></div></div><button type="button" className="admin-logout" onClick={logout}><LogOut size={16} />{t('logout')}</button></div>
    </aside>
    <div className={`admin-mobile-backdrop ${mobileOpen ? 'show' : ''}`} onMouseDown={event => { if (event.target === event.currentTarget) setMobileOpen(false); }} />
    <div className="admin-main-area">
      <header className="admin-topbar"><div className="admin-topbar-left"><IconButton className="admin-mobile-toggle" label={t('menu')} onClick={() => setMobileOpen(true)}><Menu size={20} /></IconButton><div className="admin-topbar-icon"><Store size={17} /></div><span>{locale === 'ar' ? 'لوحة إدارة سنتر الجويلي' : 'Center El Gowaily dashboard'}</span></div><div className="admin-topbar-right"><span className="admin-live-dot">{isDemoMode ? (locale === 'ar' ? 'وضع تجريبي' : 'Demo mode') : 'Connected'}</span><button type="button" className="language-button" onClick={toggleLocale}>{t('language')}</button><a href="/" target="_blank" rel="noreferrer" className="admin-view-store"><ShoppingBag size={15} />{locale === 'ar' ? 'عرض المتجر' : 'View store'}</a></div></header>
      {isDemoMode ? <div className="admin-demo-banner">{t('demoNotice')}</div> : null}
      <main className="admin-content" id="admin-content"><Outlet /></main>
    </div>
  </div>;
}
