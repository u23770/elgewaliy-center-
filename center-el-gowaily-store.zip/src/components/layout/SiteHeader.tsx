import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowUpLeft, ChevronDown, Menu, Search, ShoppingBag, UserRound, X } from 'lucide-react';
import { useLocale } from '../../contexts/LocaleContext';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { listCategories } from '../../services/repository';
import { IconButton } from '../ui/primitives';

function BrandLockup() {
  const { t, locale } = useLocale();
  return <Link to="/" className="brand-lockup" aria-label={t('brand')}>
    <span className="brand-mark" aria-hidden="true"><span>ج</span><i /></span>
    <span className="brand-words"><strong>{locale === 'ar' ? 'الجويلي' : 'EL GOWAILY'}</strong><small>{locale === 'ar' ? 'سنتر' : 'CENTER'}</small></span>
  </Link>;
}

export function SiteHeader() {
  const { t, toggleLocale, localized, locale } = useLocale();
  const { user } = useAuth();
  const { itemCount, openDrawer } = useCart();
  const { data: categoryData } = useAsyncData(listCategories, []);
  const categories = categoryData ?? [];
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState(false);
  const [query, setQuery] = useState('');
  const navigate = useNavigate();
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') setMobileOpen(false); };
    document.addEventListener('keydown', onKey);
    document.body.classList.add('menu-open');
    return () => { document.removeEventListener('keydown', onKey); document.body.classList.remove('menu-open'); };
  }, [mobileOpen]);

  const submitSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const value = query.trim();
    navigate(value ? `/search?q=${encodeURIComponent(value)}` : '/shop');
    setMobileSearch(false); setMobileOpen(false);
  };
  const closeMenu = () => setMobileOpen(false);

  return <>
    <div className="announcement"><span>{locale === 'ar' ? 'اختيارات جديدة وصلت للتو' : 'A fresh edit has just landed'}</span><span className="announcement-dot">·</span><Link to="/shop">{t('shopNow')} <ArrowUpLeft size={12} /></Link></div>
    <header className="site-header">
      <div className="header-main page-container">
        <div className="header-brand"><BrandLockup /></div>
        <nav className="desktop-primary-nav" aria-label={t('categories')}>
          <Link to="/">{t('home')}</Link>
          <Link to="/shop">{t('shop')}</Link>
          {categories.slice(0, 3).map(category => <Link to={`/category/${category.slug}`} key={category.id}>{localized(category.name)}</Link>)}
        </nav>
        <form className="header-search" onSubmit={submitSearch} role="search">
          <Search size={17} aria-hidden="true" />
          <input value={query} onChange={event => setQuery(event.target.value)} aria-label={t('search')} placeholder={t('searchPlaceholder')} />
          <button type="submit" aria-label={t('search')}><ArrowUpLeft size={16} /></button>
        </form>
        <div className="header-actions">
          <button className="language-button" type="button" onClick={toggleLocale} aria-label={t('language')}>{t('language')}</button>
          <Link className="header-account" to={user ? (user.role === 'admin' ? '/admin' : '/account') : '/login'} aria-label={t('account')}>
            <UserRound size={18} /><span>{user ? (user.fullName || t('account')) : t('account')}</span>
          </Link>
          <button className="header-bag" type="button" aria-label={`${t('cart')} (${itemCount})`} onClick={openDrawer}>
            <ShoppingBag size={19} /><span className="header-bag-label">{t('cart')}</span><span className="bag-count">{itemCount}</span>
          </button>
          <IconButton className="mobile-search-trigger" label={t('search')} onClick={() => setMobileSearch(value => !value)}><Search size={19} /></IconButton>
          <IconButton className="mobile-menu-trigger" label={mobileOpen ? t('close') : t('menu')} onClick={() => setMobileOpen(value => !value)}>{mobileOpen ? <X size={21} /> : <Menu size={21} />}</IconButton>
        </div>
      </div>
      <div className="desktop-category-strip page-container" aria-label={t('categories')}>
        <Link to="/shop">{t('allProducts')}</Link>
        {categories.slice(0, 6).map(category => <Link to={`/category/${category.slug}`} key={category.id}>{localized(category.name)}</Link>)}
        <Link to="/about" className="category-strip-story">{t('about')} <ChevronDown size={12} /></Link>
      </div>
      {mobileSearch ? <form className="mobile-search-panel" onSubmit={submitSearch} role="search">
        <Search size={18} /><input autoFocus value={query} onChange={event => setQuery(event.target.value)} placeholder={t('searchPlaceholder')} aria-label={t('search')} />
        <button type="submit">{t('search')}</button>
      </form> : null}
    </header>
    <div className={`mobile-nav-overlay ${mobileOpen ? 'visible' : ''}`} onMouseDown={event => { if (event.target === event.currentTarget) closeMenu(); }} aria-hidden={!mobileOpen}>
      <nav className={`mobile-nav-panel ${mobileOpen ? 'open' : ''}`} ref={navRef} aria-label={t('menu')}>
        <div className="mobile-nav-heading"><BrandLockup /><IconButton label={t('close')} onClick={closeMenu}><X size={20} /></IconButton></div>
        <div className="mobile-nav-links">
          <Link to="/" onClick={closeMenu}>{t('home')}</Link><Link to="/shop" onClick={closeMenu}>{t('allProducts')}</Link>
          <div className="mobile-nav-label">{t('categories')}</div>
          {categories.map(category => <Link to={`/category/${category.slug}`} onClick={closeMenu} key={category.id}>{localized(category.name)}<ArrowUpLeft size={15} /></Link>)}
          <Link to="/about" onClick={closeMenu}>{t('about')}</Link><Link to="/help" onClick={closeMenu}>{t('help')}</Link>
          {user?.role === 'admin' ? <Link to="/admin" onClick={closeMenu}>{t('admin')}</Link> : null}
        </div>
        <div className="mobile-nav-bottom"><button className="language-button" type="button" onClick={toggleLocale}>{t('language')}</button><Link to={user ? '/account' : '/login'} onClick={closeMenu}><UserRound size={17} />{user ? (user.fullName || t('account')) : t('login')}</Link></div>
      </nav>
    </div>
  </>;
}
