import { ArrowUpLeft, Instagram, MapPin, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getStoreSettings, listCategories } from '../../services/repository';
import { useAsyncData } from '../../hooks/useAsyncData';
import { useLocale } from '../../contexts/LocaleContext';

export function SiteFooter() {
  const { t, locale, localized } = useLocale();
  const { data: categoryData } = useAsyncData(listCategories, []);
  const { data: settings } = useAsyncData(getStoreSettings, []);
  const categories = categoryData ?? [];
  const phone = settings?.phone || '+20 100 000 0000';
  const phoneHref = `tel:${phone.replace(/[^+0-9]/g, '')}`;
  return <footer className="site-footer">
    <div className="page-container footer-main">
      <div className="footer-brand-block">
        <Link to="/" className="footer-brand"><span className="brand-mark"><span>ج</span><i /></span><span>{locale === 'ar' ? 'سنتر الجويلي' : 'CENTER EL GOWAILY'}</span></Link>
        <p>{t('footerNote')}</p>
        <div className="footer-social"><a href="https://www.instagram.com/" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={17} /></a><a href={phoneHref} aria-label={t('contactUs')}><Phone size={17} /></a></div>
      </div>
      <div className="footer-column"><h3>{t('quickLinks')}</h3><Link to="/shop">{t('allProducts')}</Link>{categories.slice(0, 4).map(category => <Link to={`/category/${category.slug}`} key={category.id}>{localized(category.name)}</Link>)}</div>
      <div className="footer-column"><h3>{t('helpLinks')}</h3><Link to="/help">{t('help')}</Link><Link to="/track">{t('trackOrder')}</Link><Link to="/about">{t('about')}</Link></div>
      <div className="footer-contact"><h3>{t('contactUs')}</h3><span><MapPin size={16} />{locale === 'ar' ? 'القاهرة، مصر' : 'Cairo, Egypt'}</span><a href={phoneHref}><Phone size={16} />{phone}</a><Link to="/shop" className="footer-cta">{t('shopNow')} <ArrowUpLeft size={15} /></Link></div>
    </div>
    <div className="footer-bottom page-container"><span>© {new Date().getFullYear()} {locale === 'ar' ? 'سنتر الجويلي' : 'Center El Gowaily'}</span><span>{locale === 'ar' ? 'صُنع بعناية ليومك' : 'Made for your everyday.'}</span></div>
  </footer>;
}
