import { Outlet } from 'react-router-dom';
import { SiteHeader } from './SiteHeader';
import { SiteFooter } from './SiteFooter';
import { CartDrawer } from '../cart/CartDrawer';

export function CustomerShell() {
  return <div className="app-shell"><SiteHeader /><main id="main-content"><Outlet /></main><SiteFooter /><CartDrawer /></div>;
}
