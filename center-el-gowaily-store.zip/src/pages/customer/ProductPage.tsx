import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, ArrowUpLeft, Check, Maximize2, Minus, Plus, ShieldCheck, Truck } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import type { Product, ProductColor, ProductImage, ProductVariant } from '../../types';
import { useLocale } from '../../contexts/LocaleContext';
import { useCart } from '../../contexts/CartContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { getProductBySlug, listProducts } from '../../services/repository';
import { discountPercent, effectivePrice } from '../../utils/format';
import { Button, EmptyState, ErrorState, Modal, ProductGridSkeleton } from '../../components/ui/primitives';
import { ProductGrid } from '../../components/product/ProductGrid';
import { usePageMeta } from '../../hooks/usePageMeta';

function ProductGallery({ product, selectedColor }: { product: Product; selectedColor?: ProductColor }) {
  const { localized, t, dir } = useLocale();
  const [activeIndex, setActiveIndex] = useState(0);
  const [lightbox, setLightbox] = useState(false);
  const touchStart = useState<{ x: number; y: number } | null>(null);
  const images = useMemo<ProductImage[]>(() => {
    const selected = selectedColor ? product.images.filter(image => image.colorKey === selectedColor.key) : [];
    const base = selected.length ? selected : product.images.filter(image => !image.colorKey);
    const general = base.length ? base : product.images;
    const variantImage = product.variants.find(variant => variant.color?.key === selectedColor?.key && variant.imageUrl)?.imageUrl;
    return variantImage && !general.some(image => image.url === variantImage)
      ? [{ id: `variant-${selectedColor?.key}`, url: variantImage, alt: product.name, colorKey: selectedColor?.key }, ...general]
      : general;
  }, [product, selectedColor]);
  useEffect(() => { setActiveIndex(0); }, [selectedColor?.key, product.id]);
  const current = images[activeIndex] ?? images[0];
  const move = (step: number) => setActiveIndex(index => (index + step + images.length) % images.length);
  const touchStartRef = touchStart[0];
  const setTouchStart = touchStart[1];
  const swipeProps = {
    onTouchStart: (event: React.TouchEvent) => setTouchStart({ x: event.touches[0].clientX, y: event.touches[0].clientY }),
    onTouchEnd: (event: React.TouchEvent) => {
      const start = touchStartRef; if (!start) return;
      const dx = event.changedTouches[0].clientX - start.x;
      const dy = event.changedTouches[0].clientY - start.y;
      if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) move(dx < 0 ? 1 : -1);
      setTouchStart(null);
    },
  };
  if (!current) return <div className="product-gallery-placeholder" />;
  const ArrowPrev = dir === 'rtl' ? ArrowRight : ArrowLeft;
  const ArrowNext = dir === 'rtl' ? ArrowLeft : ArrowRight;
  return <div className="product-gallery">
    <div className="product-gallery-main" {...swipeProps}>
      <img src={current.url} alt={localized(current.alt) || localized(product.name)} onError={event => { event.currentTarget.src = '/images/fallback.svg'; }} />
      <div className="gallery-count">{String(activeIndex + 1).padStart(2, '0')} <i /> {String(images.length).padStart(2, '0')}</div>
      <button className="gallery-expand" type="button" aria-label={t('details')} onClick={() => setLightbox(true)}><Maximize2 size={17} /></button>
      {images.length > 1 ? <><button className="gallery-arrow gallery-prev" type="button" aria-label={dir === 'rtl' ? 'التالي' : 'Previous image'} onClick={() => move(-1)}><ArrowPrev size={19} /></button><button className="gallery-arrow gallery-next" type="button" aria-label={dir === 'rtl' ? 'السابق' : 'Next image'} onClick={() => move(1)}><ArrowNext size={19} /></button></> : null}
    </div>
    {images.length > 1 ? <div className="gallery-thumbnails" role="tablist" aria-label={t('details')}>{images.map((image, index) => <button type="button" role="tab" aria-selected={activeIndex === index} className={activeIndex === index ? 'active' : ''} key={image.id} onClick={() => setActiveIndex(index)}><img src={image.url} alt={localized(image.alt) || `${localized(product.name)} ${index + 1}`} /></button>)}</div> : null}
    <Modal open={lightbox} onClose={() => setLightbox(false)} title={localized(product.name)} className="lightbox-modal">
      <div className="lightbox-image-wrap"><img src={current.url} alt={localized(current.alt) || localized(product.name)} />{images.length > 1 ? <><button type="button" className="gallery-arrow lightbox-prev" onClick={() => move(-1)} aria-label="Previous image"><ArrowPrev size={20} /></button><button type="button" className="gallery-arrow lightbox-next" onClick={() => move(1)} aria-label="Next image"><ArrowNext size={20} /></button></> : null}</div>
    </Modal>
  </div>;
}

function RelatedProducts({ product }: { product: Product }) {
  const { t } = useLocale();
  const { data, loading, error, retry } = useAsyncData(async () => (await listProducts()).filter(item => item.id !== product.id && (item.categoryId === product.categoryId || item.featured)).slice(0, 4), [product.id, product.categoryId]);
  return <section className="related-products section-block"><div className="page-container"><div className="section-heading"><div><div className="eyebrow">{t('featured')}</div><h2>{t('related')}</h2></div></div>{error ? <ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /> : loading ? <ProductGridSkeleton count={4} /> : <ProductGrid products={data ?? []} />}</div></section>;
}

function VariantPicker({ product, color, size, onColor, onSize }: { product: Product; color: string; size: string; onColor: (key: string) => void; onSize: (size: string) => void }) {
  const { t, localized } = useLocale();
  const colorOptions = [...new Map(product.variants.filter(v => v.active && v.color).map(v => [v.color!.key, v.color!])).values()];
  const hasColor = colorOptions.length > 0;
  const hasSize = product.variants.some(v => v.active && v.size);
  return <div className="variant-picker">
    {hasColor ? <fieldset className="variant-group"><legend>{t('color')} <span>{localized(colorOptions.find(item => item.key === color)?.name)}</span></legend><div className="swatch-options">{colorOptions.map(option => {
      const available = product.variants.some(variant => variant.active && variant.color?.key === option.key && variant.stock > 0);
      return <button type="button" key={option.key} className={`swatch-option ${color === option.key ? 'selected' : ''} ${!available ? 'unavailable' : ''}`} style={{ '--swatch': option.hex } as React.CSSProperties} onClick={() => available && onColor(option.key)} disabled={!available} aria-label={localized(option.name)} title={localized(option.name)}><span />{color === option.key ? <Check size={13} /> : null}</button>;
    })}</div></fieldset> : null}
    {hasSize ? <fieldset className="variant-group"><legend>{t('size')} <span>{size || t('selectSize')}</span></legend><div className="size-options">{[...new Set(product.variants.filter(v => v.active).map(v => v.size).filter((v): v is string => Boolean(v)))].map(option => {
      const matching = product.variants.filter(variant => variant.active && (!hasColor || variant.color?.key === color) && variant.size === option);
      const available = matching.some(variant => variant.stock > 0);
      return <button type="button" key={option} className={`size-option ${size === option ? 'selected' : ''} ${!available ? 'unavailable' : ''}`} disabled={!available} onClick={() => onSize(option)}>{option}</button>;
    })}</div></fieldset> : null}
  </div>;
}

export function ProductPage() {
  const { slug = '' } = useParams();
  const { t, localized, formatPrice, locale } = useLocale();
  const { addItem } = useCart();
  const { data: product, loading, error, retry } = useAsyncData(() => getProductBySlug(slug), [slug]);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [guideOpen, setGuideOpen] = useState(false);
  useEffect(() => {
    if (!product) return;
    const firstVariant = product.variants.find(variant => variant.active && variant.stock > 0) ?? product.variants[0];
    setSelectedColor(firstVariant?.color?.key ?? ''); setSelectedSize(firstVariant?.size ?? ''); setQuantity(1);
  }, [product?.id]);
  usePageMeta(product ? `${localized(product.name)} | ${t('brand')}` : t('brand'), product ? localized(product.description) : t('shopCollection'));
  if (loading) return <div className="page-container page-space product-loading-layout"><div className="skeleton skeleton-product-gallery" /><div className="product-loading-copy"><span className="skeleton skeleton-line short" /><span className="skeleton skeleton-line" /><span className="skeleton skeleton-line medium" /><span className="skeleton skeleton-line" /></div></div>;
  if (error) return <div className="page-container page-space"><ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /></div>;
  if (!product) return <div className="page-container page-space"><EmptyState title={t('productNotFound')} description={t('noProductsBody')} action={<Link className="button button-primary" to="/shop">{t('continueShopping')}</Link>} /></div>;

  const hasColors = product.variants.some(variant => variant.active && variant.color);
  const hasSizes = product.variants.some(variant => variant.active && variant.size);
  const selectedVariant: ProductVariant | null = product.variants.length ? product.variants.find(variant => variant.active &&
    (!hasColors || variant.color?.key === selectedColor) && (!hasSizes || variant.size === selectedSize)) ?? null : null;
  const available = selectedVariant ? selectedVariant.stock > 0 : product.variants.length ? false : product.stock > 0;
  const unitPrice = effectivePrice(product, selectedVariant);
  const oldPrice = selectedVariant?.priceOverride && selectedVariant.priceOverride < product.price ? product.price : product.salePrice ? product.price : null;
  const percent = oldPrice ? discountPercent(oldPrice, unitPrice) : null;
  const inStockCount = selectedVariant ? selectedVariant.stock : product.variants.length ? product.variants.reduce((sum, variant) => sum + variant.stock, 0) : product.stock;
  const onColor = (key: string) => {
    setSelectedColor(key);
    const matching = product.variants.filter(variant => variant.active && variant.color?.key === key);
    setSelectedSize(matching.find(variant => variant.stock > 0)?.size ?? matching[0]?.size ?? ''); setQuantity(1);
  };
  const onAdd = () => {
    if (product.variants.length && !selectedVariant) return;
    addItem(product, selectedVariant, quantity);
  };
  const onQuantity = (step: number) => setQuantity(value => Math.max(1, Math.min((selectedVariant?.stock ?? product.stock), value + step)));
  return <>
    <div className="page-container product-page page-space">
      <div className="shop-breadcrumb"><Link to="/">{t('home')}</Link><span>/</span><Link to="/shop">{t('shop')}</Link><span>/</span><span>{localized(product.name)}</span></div>
      <div className="product-detail-layout">
        <ProductGallery product={product} selectedColor={product.variants.find(variant => variant.color?.key === selectedColor)?.color} />
        <div className="product-detail-copy">
          <div className="product-detail-category"><span className="eyebrow">{localized(product.category)}</span><span className={`product-availability ${available ? 'is-available' : 'is-unavailable'}`}><i />{available ? t('available') : t('soldOut')}</span></div>
          <h1>{localized(product.name)}</h1>
          <div className="detail-rating-row"><span className="detail-sku">{product.sku}</span><span className="detail-dot" /><span className="detail-stock-note">{inStockCount > 0 && inStockCount <= 5 ? t('lowStock') : available ? t('inStock') : t('outOfStock')}</span></div>
          <div className="product-detail-price"><strong>{formatPrice(unitPrice)}</strong>{oldPrice ? <><del>{formatPrice(oldPrice)}</del>{percent ? <span className="sale-badge">-{percent}%</span> : null}</> : null}</div>
          <div className="product-description"><h2>{t('details')}</h2><p>{localized(product.description)}</p></div>
          {product.variants.length ? <VariantPicker product={product} color={selectedColor} size={selectedSize} onColor={onColor} onSize={setSelectedSize} /> : null}
          {!product.variants.length ? <div className="simple-stock-note">{available ? `${t('available')} · ${product.stock}` : t('soldOut')}</div> : null}
          <div className="product-actions-row">
            <div className="quantity-select"><span>{t('quantity')}</span><div className="quantity-stepper"><button type="button" aria-label="Increase quantity" disabled={!available || quantity >= (selectedVariant?.stock ?? product.stock)} onClick={() => onQuantity(1)}><Plus size={15} /></button><span>{quantity}</span><button type="button" aria-label="Decrease quantity" disabled={quantity <= 1} onClick={() => onQuantity(-1)}><Minus size={15} /></button></div></div>
            <Button size="lg" className="product-add-button" disabled={!available || (product.variants.length > 0 && !selectedVariant)} onClick={onAdd}><span>{available ? t('addToBag') : t('soldOut')}</span><ArrowUpLeft size={18} /></Button>
          </div>
          {product.variants.length && !selectedVariant ? <p className="selection-hint">{hasColors && !selectedColor ? t('selectColor') : t('selectSize')}</p> : null}
          <button className="size-guide-link" type="button" onClick={() => setGuideOpen(true)}>{t('sizeGuide')} <ArrowUpLeft size={14} /></button>
          <div className="product-service-notes"><div><Truck size={17} /><span>{locale === 'ar' ? 'توصيل لجميع المحافظات' : 'Delivery across Egypt'}</span></div><div><ShieldCheck size={17} /><span>{locale === 'ar' ? 'دفع عند الاستلام' : 'Pay on delivery'}</span></div></div>
          <div className="product-promise"><span className="promise-line" /><p>{t('detailsBody')}</p></div>
        </div>
      </div>
    </div>
    <RelatedProducts product={product} />
    <Modal open={guideOpen} onClose={() => setGuideOpen(false)} title={t('sizeGuide')}>
      <p className="size-guide-copy">{locale === 'ar' ? 'اختَر المقاس الذي ترتديه عادةً. إذا كنت بين مقاسين، ننصح بالمقاس الأكبر لقصّة أكثر راحة.' : 'Choose the size you usually wear. If you are between sizes, we recommend sizing up for a more relaxed fit.'}</p>
      <div className="size-guide-table"><div><strong>{t('size')}</strong><strong>{locale === 'ar' ? 'الصدر (سم)' : 'Chest (cm)'}</strong><strong>{locale === 'ar' ? 'الطول (سم)' : 'Length (cm)'}</strong></div>{['S', 'M', 'L', 'XL'].map((size, index) => <div key={size}><span>{size}</span><span>{[92, 100, 108, 116][index]}</span><span>{[66, 69, 72, 75][index]}</span></div>)}</div>
    </Modal>
  </>;
}
