import { ArrowUpLeft, ArrowRight, ArrowLeft, MoveUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLocale } from '../../contexts/LocaleContext';
import { listCategories, listProducts } from '../../services/repository';
import { useAsyncData } from '../../hooks/useAsyncData';
import { ProductGrid } from '../../components/product/ProductGrid';
import { EmptyState, ErrorState, SectionHeading } from '../../components/ui/primitives';
import { usePageMeta } from '../../hooks/usePageMeta';

export function HomePage() {
  const { t, localized, locale } = useLocale();
  const { data, loading, error, retry } = useAsyncData(async () => {
    const [categories, products] = await Promise.all([listCategories(), listProducts({ sort: 'featured' })]);
    return { categories, products };
  }, []);
  usePageMeta(locale === 'ar' ? 'سنتر الجويلي | اختيارات يومية مدروسة' : 'Center El Gowaily | Everyday, considered', t('tagline'));
  const Arrow = locale === 'ar' ? ArrowLeft : ArrowRight;

  return <div className="home-page">
    <section className="hero page-container">
      <img className="hero-image" src="/images/hero-editorial.jpg" alt="" fetchPriority="high" />
      <div className="hero-overlay" />
      <div className="hero-content">
        <div className="hero-eyebrow"><span />{t('heroEyebrow')}</div>
        <h1>{t('heroTitle').split('\n').map((line, index) => <span key={line}>{line}{index === 0 ? <br /> : null}</span>)}</h1>
        <p>{t('heroBody')}</p>
        <div className="hero-actions"><Link to="/shop" className="button button-primary button-lg">{t('shopNow')}<Arrow size={18} /></Link><Link className="hero-secondary-link" to={data?.categories[0] ? `/category/${data.categories[0].slug}` : '/shop'}>{t('discover')} <Arrow size={16} /></Link></div>
        <div className="hero-footnote"><span className="hero-footnote-line" />{locale === 'ar' ? 'قاهرة، مصر · من أجلك' : 'Cairo, Egypt · made for you'}</div>
      </div>
      <div className="hero-index"><span>01</span><i />03</div>
    </section>

    <section className="page-container home-categories section-block">
      <SectionHeading eyebrow={t('categories')} title={t('categoriesTitle')} description={t('categoriesBody')} action={<Link className="text-link" to="/shop">{t('viewAll')} <ArrowUpLeft size={15} /></Link>} />
      {error ? <ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /> : loading ? <div className="category-grid">{[0,1,2,3].map(index => <div className="skeleton category-skeleton" key={index} />)}</div> : data?.categories.length ? <div className="category-grid">
        {data.categories.slice(0, 4).map((category, index) => <Link to={`/category/${category.slug}`} className={`category-feature category-feature-${index + 1}`} key={category.id}>
          <img src={category.image || '/images/fallback.svg'} alt="" loading="lazy" />
          <span className="category-feature-shade" /><span className="category-feature-index">0{index + 1}</span>
          <span className="category-feature-name">{localized(category.name)}<MoveUpRight size={19} /></span>
        </Link>)}
      </div> : <EmptyState title={t('categories')} description={t('noProductsBody')} action={<Link className="button button-secondary" to="/shop">{t('allProducts')}</Link>} />}
    </section>

    <section className="featured-section section-block">
      <div className="page-container"><SectionHeading eyebrow={t('featured')} title={t('newArrivals')} description={t('featuredBody')} action={<Link className="text-link" to="/shop">{t('viewAll')} <ArrowUpLeft size={15} /></Link>} />
        {error ? <ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /> : loading ? <ProductGrid products={[]} loading skeletonCount={4} /> : data?.products.length ? <ProductGrid products={data.products.slice(0, 4)} /> : <EmptyState title={t('noProducts')} description={t('noProductsBody')} action={<Link className="button button-primary" to="/shop">{t('shopNow')}</Link>} />}
      </div>
    </section>

    <section className="home-editorial page-container section-block">
      <div className="editorial-photo"><img src="/images/look-women.jpg" alt="" loading="lazy" /><span className="editorial-stamp">ELG<br />01</span></div>
      <div className="editorial-copy"><span className="eyebrow">{t('promoEyebrow')}</span><h2>{t('promoTitle')}</h2><p>{t('promoBody')}</p><Link className="editorial-link" to="/shop">{t('shopCollection')} <ArrowUpLeft size={16} /></Link><span className="editorial-decoration">E/G</span></div>
    </section>

    {(data?.categories ?? []).length ? <section className="page-container category-rail-section section-block">
      <div className="category-rail-heading"><div><span className="eyebrow">{locale === 'ar' ? 'اختَر وجهتك' : 'FIND YOUR WAY'}</span><h2>{locale === 'ar' ? 'كل خزانة لها حكاية.' : 'Every wardrobe has a story.'}</h2></div><Link className="text-link" to="/shop">{t('allProducts')} <ArrowUpLeft size={15} /></Link></div>
      <div className="category-rail">{(data?.categories ?? []).slice(0, 6).map((category, index) => <Link key={category.id} to={`/category/${category.slug}`} className="category-rail-item"><span className="category-rail-no">0{index + 1}</span><span>{localized(category.name)}</span><ArrowUpLeft size={16} /></Link>)}</div>
    </section> : null}
  </div>;
}
