import { useEffect, useMemo, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { useLocale } from '../../contexts/LocaleContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { listCategories, listProducts } from '../../services/repository';
import { ProductGrid } from '../../components/product/ProductGrid';
import { Button, EmptyState, ErrorState, PageHeader, SelectField } from '../../components/ui/primitives';
import { usePageMeta } from '../../hooks/usePageMeta';
import type { Product } from '../../types';

function FilterContents({ products, selectedSize, setSelectedSize, selectedColor, setSelectedColor, onlyAvailable, setOnlyAvailable, maxPrice, setMaxPrice, onClear }: {
  products: Product[]; selectedSize: string; setSelectedSize: (value: string) => void; selectedColor: string; setSelectedColor: (value: string) => void;
  onlyAvailable: boolean; setOnlyAvailable: (value: boolean) => void; maxPrice: string; setMaxPrice: (value: string) => void; onClear: () => void;
}) {
  const { t } = useLocale();
  const sizes = [...new Set(products.flatMap(product => product.variants.map(variant => variant.size).filter((value): value is string => Boolean(value))))];
  const colors = [...new Map(products.flatMap(product => product.variants.flatMap(variant => variant.color ? [[variant.color.key, variant.color] as const] : [])).map(([key, value]) => [key, value])).values()];
  return <div className="filter-panel-content">
    <div className="filter-head"><h3>{t('filters')}</h3><button type="button" className="text-action" onClick={onClear}>{t('clearFilters')}</button></div>
    <label className="filter-group"><span>{t('underPrice')}</span><div className="filter-price-input"><input inputMode="numeric" type="number" min="0" value={maxPrice} onChange={event => setMaxPrice(event.target.value)} placeholder="—" /><span>EGP</span></div></label>
    {sizes.length ? <fieldset className="filter-group"><legend>{t('size')}</legend><div className="filter-size-list">{sizes.map(size => <button type="button" key={size} className={`filter-size ${selectedSize === size ? 'selected' : ''}`} onClick={() => setSelectedSize(selectedSize === size ? '' : size)}>{size}</button>)}</div></fieldset> : null}
    {colors.length ? <fieldset className="filter-group"><legend>{t('color')}</legend><div className="filter-color-list">{colors.map(color => <button type="button" key={color.key} className={`filter-color ${selectedColor === color.key ? 'selected' : ''}`} onClick={() => setSelectedColor(selectedColor === color.key ? '' : color.key)} title={color.name.en} aria-label={color.name.en}><i style={{ backgroundColor: color.hex }} /></button>)}</div></fieldset> : null}
    <label className="filter-checkbox"><input type="checkbox" checked={onlyAvailable} onChange={event => setOnlyAvailable(event.target.checked)} /><span>{t('inStock')}</span></label>
  </div>;
}

export function ShopPage() {
  const params = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const { t, localized } = useLocale();
  const { data: allProducts, loading, error, retry } = useAsyncData(() => listProducts({ sort: 'featured' }), []);
  const { data: categoryData } = useAsyncData(listCategories, []);
  const categories = categoryData ?? [];
  const [sort, setSort] = useState(searchParams.get('sort') ?? 'featured');
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const query = searchParams.get('q') ?? '';
  const categorySlug = params.slug;
  const category = categories.find(item => item.slug === categorySlug);

  useEffect(() => { setSort(searchParams.get('sort') ?? 'featured'); }, [searchParams]);
  const filtered = useMemo(() => {
    let list = [...(allProducts ?? [])];
    if (query.trim()) {
      const q = query.trim().toLocaleLowerCase();
      list = list.filter(product => [product.name.en, product.name.ar, product.description.en, product.description.ar, product.sku].some(value => value.toLocaleLowerCase().includes(q)));
    }
    if (categorySlug) {
      const categoryIds = new Set(categories.filter(item => item.slug === categorySlug || item.id === categorySlug).map(item => item.id));
      list = list.filter(product => categoryIds.has(product.categoryId));
    }
    if (selectedSize) list = list.filter(product => product.variants.some(variant => variant.size === selectedSize && variant.stock > 0));
    if (selectedColor) list = list.filter(product => product.variants.some(variant => variant.color?.key === selectedColor && variant.stock > 0));
    if (onlyAvailable) list = list.filter(product => product.variants.length ? product.variants.some(variant => variant.stock > 0) : product.stock > 0);
    const max = Number(maxPrice); if (max > 0) list = list.filter(product => (product.salePrice ?? product.price) <= max);
    if (sort === 'price-asc') list.sort((a, b) => (a.salePrice ?? a.price) - (b.salePrice ?? b.price));
    if (sort === 'price-desc') list.sort((a, b) => (b.salePrice ?? b.price) - (a.salePrice ?? a.price));
    if (sort === 'newest') list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (sort === 'featured') list.sort((a, b) => Number(b.featured) - Number(a.featured));
    return list;
  }, [allProducts, query, categorySlug, categories, selectedSize, selectedColor, onlyAvailable, maxPrice, sort]);

  const pageTitle = query ? `${t('search')}: ${query}` : category ? localized(category.name) : t('allProducts');
  usePageMeta(`${pageTitle} | ${t('brand')}`, t('shopCollection'));
  const clear = () => { setSelectedSize(''); setSelectedColor(''); setMaxPrice(''); setOnlyAvailable(false); };
  const changeSort = (value: string) => { setSort(value); const next = new URLSearchParams(searchParams); next.set('sort', value); setSearchParams(next, { replace: true }); };

  return <div className="page-container shop-page page-space">
    <div className="shop-breadcrumb"><Link to="/">{t('home')}</Link><span>/</span>{category ? localized(category.name) : query ? t('search') : t('shop')}</div>
    <PageHeader eyebrow={query ? t('search') : t('shop')} title={pageTitle} description={category ? localized(category.description) : query ? `${filtered.length} ${t('results')}` : t('featuredBody')} />
    <div className="shop-toolbar">
      <div className="shop-result-count"><span>{filtered.length}</span> {t('results')}</div>
      <div className="shop-toolbar-actions"><button type="button" className="filter-toggle" onClick={() => setFiltersOpen(value => !value)}><SlidersHorizontal size={16} />{t('filters')}<span>{[selectedSize, selectedColor, maxPrice, onlyAvailable ? '1' : ''].filter(Boolean).length || ''}</span></button>
        <SelectField className="sort-select" label={t('sort')} value={sort} onChange={event => changeSort(event.target.value)}>
          <option value="featured">{t('featuredSort')}</option><option value="newest">{t('newest')}</option><option value="price-asc">{t('priceLow')}</option><option value="price-desc">{t('priceHigh')}</option>
        </SelectField>
      </div>
    </div>
    <div className="shop-layout">
      <aside className="shop-sidebar"><FilterContents products={allProducts ?? []} selectedSize={selectedSize} setSelectedSize={setSelectedSize} selectedColor={selectedColor} setSelectedColor={setSelectedColor} onlyAvailable={onlyAvailable} setOnlyAvailable={setOnlyAvailable} maxPrice={maxPrice} setMaxPrice={setMaxPrice} onClear={clear} /></aside>
      <div className="shop-results">
        <div className="category-pills"><Link to="/shop" className={!categorySlug ? 'active' : ''}>{t('allCategories')}</Link>{categories.map(item => <Link key={item.id} to={`/category/${item.slug}`} className={item.slug === categorySlug ? 'active' : ''}>{localized(item.name)}</Link>)}</div>
        {error ? <ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /> : loading ? <ProductGrid products={[]} loading skeletonCount={8} /> : filtered.length ? <ProductGrid products={filtered} /> : <EmptyState icon={<Search size={23} />} title={t('noProducts')} description={t('noProductsBody')} action={<Button variant="secondary" onClick={clear}>{t('clearFilters')}</Button>} />}
      </div>
    </div>
    <div className={`mobile-filter-backdrop ${filtersOpen ? 'open' : ''}`} onMouseDown={event => { if (event.target === event.currentTarget) setFiltersOpen(false); }}>
      <div className={`mobile-filter-sheet ${filtersOpen ? 'open' : ''}`} role="dialog" aria-modal="true" aria-label={t('filters')}><div className="mobile-filter-title"><strong>{t('filters')}</strong><button type="button" onClick={() => setFiltersOpen(false)} aria-label={t('close')}><X size={19} /></button></div><FilterContents products={allProducts ?? []} selectedSize={selectedSize} setSelectedSize={setSelectedSize} selectedColor={selectedColor} setSelectedColor={setSelectedColor} onlyAvailable={onlyAvailable} setOnlyAvailable={setOnlyAvailable} maxPrice={maxPrice} setMaxPrice={setMaxPrice} onClear={clear} /><Button className="full-width" onClick={() => setFiltersOpen(false)}>{t('viewAll')} · {filtered.length}</Button></div>
    </div>
  </div>;
}
