import { ArrowUpLeft, ArrowUpRight, CircleHelp, Mail, MapPin, Phone, RefreshCcw, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLocale } from '../../contexts/LocaleContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { getStoreSettings } from '../../services/repository';
import { usePageMeta } from '../../hooks/usePageMeta';
import { PageHeader } from '../../components/ui/primitives';

export function AboutPage() {
  const { t, locale } = useLocale();
  const { data: settings } = useAsyncData(getStoreSettings, []);
  const phone = settings?.phone || '+20 100 000 0000';
  const phoneHref = `tel:${phone.replace(/[^+0-9]/g, '')}`;
  usePageMeta(`${t('about')} | ${t('brand')}`, t('aboutBody'));
  const Arrow = locale === 'ar' ? ArrowUpLeft : ArrowUpRight;
  return <div className="page-container page-space info-page about-page">
    <div className="about-hero"><div><div className="eyebrow">CENTER EL GOWAILY · CAIRO</div><h1>{t('aboutTitle')}</h1><p>{t('aboutBody')}</p><Link className="button button-primary button-lg" to="/shop">{t('shopNow')} <Arrow size={16} /></Link></div><img src="/images/hero-editorial.jpg" alt="" /></div>
    <div className="about-values"><div><span>01</span><h2>{locale === 'ar' ? 'اختيارات مدروسة' : 'Considered picks'}</h2><p>{locale === 'ar' ? 'نركز على القطع التي تستحق مكانًا في خزانة ملابسك.' : 'We focus on pieces that earn their place in your wardrobe.'}</p></div><div><span>02</span><h2>{locale === 'ar' ? 'راحة كل يوم' : 'Everyday comfort'}</h2><p>{locale === 'ar' ? 'قصّات سهلة وخامات تواكب تفاصيل يومك.' : 'Easy fits and considered fabrics that move with your day.'}</p></div><div><span>03</span><h2>{locale === 'ar' ? 'من القاهرة، إليك' : 'From Cairo, to you'}</h2><p>{locale === 'ar' ? 'وجهة محلية للأناقة العملية بخدمة قريبة وواضحة.' : 'A local destination for useful style and straightforward service.'}</p></div></div>
    <div className="about-contact"><span className="eyebrow">{t('contactUs')}</span><h2>{locale === 'ar' ? 'نحن هنا إذا احتجت إلينا.' : 'We are here when you need us.'}</h2><div><a href={phoneHref}><Phone size={16} />{phone}</a><span><MapPin size={16} />{locale === 'ar' ? 'القاهرة، مصر' : 'Cairo, Egypt'}</span><Link to="/help">{t('help')} <Arrow size={15} /></Link></div></div>
  </div>;
}

export function HelpPage() {
  const { t, locale } = useLocale();
  const { data: settings } = useAsyncData(getStoreSettings, []);
  const phone = settings?.phone || '+20 100 000 0000';
  const phoneHref = `tel:${phone.replace(/[^+0-9]/g, '')}`;
  usePageMeta(`${t('help')} | ${t('brand')}`, t('trackingTitle'));
  const faqs = locale === 'ar' ? [
    ['كيف يمكنني تتبع طلبي؟', 'افتح صفحة تتبع الطلب وأدخل رقم الطلب ورقم الهاتف المستخدم عند الشراء.'],
    ['ما طرق الدفع المتاحة؟', 'يمكنك الدفع نقدًا أو بالبطاقة عند الاستلام. لا نطلب بيانات بطاقة إلكترونية في الوقت الحالي.'],
    ['كيف يتم احتساب التوصيل؟', 'تظهر رسوم التوصيل التقديرية في الحقيبة ويُؤكد المبلغ النهائي عند تسجيل الطلب.'],
    ['كيف أختار المقاس؟', 'تظهر المقاسات والألوان المتاحة في صفحة كل منتج. القطع غير المتاحة لا يمكن إضافتها للحقيبة.'],
  ] : [
    ['How do I track an order?', 'Open the order tracking page and enter the order number and the phone used at checkout.'],
    ['Which payment methods are available?', 'Choose cash or card on delivery. We do not collect online card details at this time.'],
    ['How is delivery calculated?', 'An estimated fee is shown in your bag and the final fee is confirmed when the order is created.'],
    ['How do I choose a size?', 'Available sizes and colours are listed on each product page. Unavailable variants cannot be added to your bag.'],
  ];
  return <div className="page-container page-space help-page"><PageHeader eyebrow={t('help')} title={t('helpLinks')} description={locale === 'ar' ? 'إجابات واضحة لأسئلتك اليومية.' : 'A few clear answers for the things you might wonder about.'} />
    <div className="help-layout"><div className="faq-list">{faqs.map(([question, answer], index) => <details className="faq-item" key={question} open={index === 0}><summary><span>{question}</span><i>+</i></summary><p>{answer}</p></details>)}</div><aside className="help-card"><span className="help-card-icon"><CircleHelp size={22} /></span><h2>{t('contactUs')}</h2><p>{locale === 'ar' ? 'هل ما زال لديك سؤال؟ يسعدنا مساعدتك.' : 'Still have a question? We would be happy to help.'}</p><a href={phoneHref}><Phone size={16} />{phone}</a><Link to="/track" className="help-track"><ShoppingBag size={16} />{t('trackOrder')}</Link><Link to="/about"><Mail size={16} />{t('about')}</Link><Link to="/shop"><RefreshCcw size={16} />{t('returns')}</Link></aside></div>
  </div>;
}

export function NotFoundPage() {
  const { t, locale } = useLocale();
  usePageMeta(`404 | ${t('brand')}`, t('notFoundBody'));
  const Arrow = locale === 'ar' ? ArrowUpLeft : ArrowUpRight;
  return <div className="page-container page-space not-found-page"><div className="not-found-number">404</div><div className="eyebrow">{t('brand')}</div><h1>{t('notFound')}</h1><p>{t('notFoundBody')}</p><div className="not-found-actions"><Link className="button button-primary button-lg" to="/">{t('backHome')} <Arrow size={16} /></Link><Link className="button button-secondary button-lg" to="/shop">{t('shop')}</Link></div><span className="not-found-decoration">E/G</span></div>;
}
