import { useState, type FormEvent } from 'react';
import { ArrowUpLeft, ClipboardList, LogOut, PackageCheck, UserRound } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useLocale } from '../../contexts/LocaleContext';
import { useToast } from '../../contexts/ToastContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { listOrders } from '../../services/repository';
import { Button, ErrorState, PageHeader, TextField } from '../../components/ui/primitives';
import { formatDate } from '../../utils/format';
import { usePageMeta } from '../../hooks/usePageMeta';

export function AccountPage() {
  const { user, updateProfile, signOut } = useAuth(); const { t, formatPrice, locale } = useLocale(); const { notify } = useToast(); const navigate = useNavigate();
  const { data: orderData, loading: ordersLoading, error: orderError, retry } = useAsyncData(() => listOrders(user), [user?.id]);
  const orders = orderData ?? [];
  const [name, setName] = useState(user?.fullName ?? ''); const [phone, setPhone] = useState(user?.phone ?? ''); const [saving, setSaving] = useState(false); const [error, setError] = useState('');
  usePageMeta(`${t('account')} | ${t('brand')}`, t('profileSubtitle'));
  const submit = async (event: FormEvent) => { event.preventDefault(); setSaving(true); setError(''); try { await updateProfile({ fullName: name, phone }); notify(t('saved')); } catch { setError(t('somethingWrong')); } finally { setSaving(false); } };
  const logout = async () => { await signOut(); navigate('/'); };
  return <div className="page-container page-space account-page">
    <PageHeader eyebrow={t('account')} title={t('profile')} description={t('profileSubtitle')} actions={<Button variant="secondary" onClick={logout}><LogOut size={16} />{t('logout')}</Button>} />
    <div className="account-layout"><aside className="account-sidebar"><div className="account-avatar"><UserRound size={26} /></div><strong>{user?.fullName || user?.email}</strong><span>{user?.email}</span><Link to="/orders" className="account-nav-link active"><ClipboardList size={17} />{t('orderHistory')}<ArrowUpLeft size={14} /></Link><Link to="/track" className="account-nav-link"><PackageCheck size={17} />{t('trackOrder')}<ArrowUpLeft size={14} /></Link></aside>
      <div className="account-main"><section className="account-card"><div className="account-card-heading"><div><span className="eyebrow">{t('profile')}</span><h2>{t('profileSubtitle')}</h2></div></div><form className="profile-form" onSubmit={submit}><TextField label={t('customerName')} required value={name} onChange={event => setName(event.target.value)} /><TextField label={t('email')} type="email" value={user?.email ?? ''} disabled /><TextField label={t('phone')} type="tel" value={phone} onChange={event => setPhone(event.target.value)} />{error ? <div className="form-alert">{error}</div> : null}<div className="profile-form-actions"><Button loading={saving}>{t('saveChanges')}</Button></div></form></section>
      <section className="account-card account-order-preview"><div className="account-card-heading"><div><span className="eyebrow">{t('orders')}</span><h2>{t('orderHistory')}</h2></div><Link className="text-link" to="/orders">{t('viewAll')} <ArrowUpLeft size={14} /></Link></div>{ordersLoading ? <div className="order-list-skeleton"><span className="skeleton skeleton-line" /><span className="skeleton skeleton-line" /></div> : orderError ? <ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /> : orders.slice(0, 3).length ? orders.slice(0, 3).map(order => <Link to={`/orders/${order.id}`} className="account-order-row" key={order.id}><div><strong>{order.orderNumber}</strong><span>{formatDate(order.createdAt, locale)}</span></div><strong>{formatPrice(order.total)}</strong></Link>) : <p className="account-muted">{t('noOrdersBody')}</p>}</section></div></div>
  </div>;
}
