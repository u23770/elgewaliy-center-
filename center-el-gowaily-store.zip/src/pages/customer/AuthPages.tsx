import { useEffect, useState, type FormEvent } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, KeyRound, LockKeyhole, MailCheck, ShieldCheck } from 'lucide-react';
import { Link, Navigate, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useLocale } from '../../contexts/LocaleContext';
import { useToast } from '../../contexts/ToastContext';
import { isDemoMode, supabase } from '../../services/supabase';
import { Button, TextField } from '../../components/ui/primitives';
import { usePageMeta } from '../../hooks/usePageMeta';

function AuthShell({ children, title, subtitle, eyebrow }: { children: React.ReactNode; title: string; subtitle: string; eyebrow: string }) {
  return <div className="auth-page page-container page-space"><div className="auth-visual"><img src="/images/look-women.jpg" alt="" /><div className="auth-visual-overlay" /><div className="auth-visual-copy"><div className="eyebrow">CENTER EL GOWAILY · CAIRO</div><h2>{title}</h2><p>{subtitle}</p></div><div className="auth-visual-stamp">E<br />/G</div></div><div className="auth-form-area"><div className="auth-form-inner"><div className="eyebrow">{eyebrow}</div>{children}</div></div></div>;
}

export function LoginPage({ adminMode = false }: { adminMode?: boolean }) {
  const { t, locale } = useLocale(); const { user, signIn, isLoading, isDemoMode: demo } = useAuth(); const { notify } = useToast();
  const [searchParams] = useSearchParams(); const location = useLocation(); const navigate = useNavigate(); const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [loading, setLoading] = useState(false); const [error, setError] = useState('');
  usePageMeta(`${adminMode ? t('adminLogin') : t('login')} | ${t('brand')}`, t('loginSubtitle'));
  if (isLoading) return null;
  if (user && (!adminMode || user.role === 'admin')) return <Navigate to={adminMode ? '/admin' : user.role === 'admin' ? '/admin' : '/account'} replace />;
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setLoading(true); setError('');
    try {
      await signIn(email, password, adminMode);
      const returnTo = searchParams.get('returnTo') ?? (location.state as { from?: string } | null)?.from;
      navigate(returnTo?.startsWith('/') ? returnTo : adminMode ? '/admin' : '/account', { replace: true });
    } catch { setError(adminMode ? t('unauthorized') : t('loginFailed')); notify(adminMode ? t('unauthorized') : t('loginFailed'), 'error'); }
    finally { setLoading(false); }
  };
  const Arrow = locale === 'ar' ? ArrowLeft : ArrowRight;
  return <AuthShell eyebrow={adminMode ? t('adminLogin') : t('login')} title={adminMode ? t('admin') : t('brand')} subtitle={adminMode ? t('adminLoginBody') : t('loginSubtitle')}>
    <h1>{adminMode ? t('adminLogin') : t('login')}</h1><p className="auth-intro">{adminMode ? t('adminLoginBody') : t('loginSubtitle')}</p>
    <form className="auth-form" onSubmit={submit} noValidate>
      <TextField label={t('email')} type="email" required autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} />
      <TextField label={t('password')} type="password" required autoComplete={adminMode ? 'current-password' : 'current-password'} value={password} onChange={event => setPassword(event.target.value)} />
      {!adminMode ? <div className="auth-extra-row"><Link to="/forgot-password">{t('forgotPassword')}</Link></div> : null}
      {error ? <div className="form-alert" role="alert">{error}</div> : null}
      <Button type="submit" size="lg" className="full-width" loading={loading}>{t('login')} <Arrow size={17} /></Button>
    </form>
    {!adminMode ? <div className="auth-switch">{t('noAccount')} <Link to="/register">{t('register')}</Link></div> : null}
    {demo ? <div className="demo-notice"><ShieldCheck size={17} /><span>{t('demoNotice')}</span></div> : null}
  </AuthShell>;
}

export function RegisterPage() {
  const { t, locale } = useLocale(); const { signUp, user, isLoading, isDemoMode: demo } = useAuth(); const { notify } = useToast(); const navigate = useNavigate();
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [phone, setPhone] = useState(''); const [password, setPassword] = useState(''); const [confirm, setConfirm] = useState(''); const [error, setError] = useState(''); const [loading, setLoading] = useState(false);
  usePageMeta(`${t('register')} | ${t('brand')}`, t('registerSubtitle'));
  if (user && !isLoading) return <Navigate to="/account" replace />;
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError('');
    if (password.length < 8) { setError(t('passwordMin')); return; }
    if (password !== confirm) { setError(t('passwordMismatch')); return; }
    setLoading(true);
    try { const result = await signUp(name, email, password, phone); navigate(result.needsVerification ? '/auth/verify' : '/account', { replace: true }); }
    catch { setError(t('registerFailed')); notify(t('registerFailed'), 'error'); }
    finally { setLoading(false); }
  };
  const Arrow = locale === 'ar' ? ArrowLeft : ArrowRight;
  return <AuthShell eyebrow={t('register')} title={t('brand')} subtitle={t('registerSubtitle')}>
    <h1>{t('register')}</h1><p className="auth-intro">{t('registerSubtitle')}</p>
    <form className="auth-form" onSubmit={submit} noValidate>
      <TextField label={t('customerName')} required autoComplete="name" value={name} onChange={event => setName(event.target.value)} />
      <TextField label={t('email')} required type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} />
      <TextField label={t('phone')} type="tel" autoComplete="tel" value={phone} onChange={event => setPhone(event.target.value)} />
      <TextField label={t('password')} required type="password" autoComplete="new-password" value={password} onChange={event => setPassword(event.target.value)} hint={t('passwordMin')} />
      <TextField label={t('confirmPassword')} required type="password" autoComplete="new-password" value={confirm} onChange={event => setConfirm(event.target.value)} />
      {error ? <div className="form-alert" role="alert">{error}</div> : null}
      <Button type="submit" size="lg" className="full-width" loading={loading}>{t('register')} <Arrow size={17} /></Button>
    </form>
    <div className="auth-switch">{t('haveAccount')} <Link to="/login">{t('login')}</Link></div>
    {demo ? <div className="demo-notice"><ShieldCheck size={17} /><span>{t('demoNotice')}</span></div> : null}
  </AuthShell>;
}

export function ForgotPasswordPage() {
  const { t } = useLocale(); const { requestPasswordReset, isDemoMode: demo } = useAuth(); const { notify } = useToast();
  const [email, setEmail] = useState(''); const [sent, setSent] = useState(false); const [loading, setLoading] = useState(false); const [error, setError] = useState('');
  usePageMeta(`${t('forgotPassword')} | ${t('brand')}`, t('forgotBody'));
  const submit = async (event: FormEvent) => { event.preventDefault(); setLoading(true); setError(''); try { await requestPasswordReset(email); setSent(true); notify(t('resetSent')); } catch { setError(t('somethingWrong')); } finally { setLoading(false); } };
  return <div className="narrow-page page-container page-space"><div className="auth-simple-card"><span className="auth-simple-icon"><KeyRound size={22} /></span><div className="eyebrow">{t('login')}</div><h1>{t('forgotTitle')}</h1><p>{t('forgotBody')}</p>{sent ? <div className="success-inline"><CheckCircle2 size={18} />{t('resetSent')}</div> : <form className="auth-form" onSubmit={submit}><TextField label={t('email')} type="email" required value={email} onChange={event => setEmail(event.target.value)} />{error ? <div className="form-alert">{error}</div> : null}<Button size="lg" className="full-width" loading={loading}>{t('sendReset')}</Button></form>}<Link className="text-link auth-back-link" to="/login"><ArrowLeft size={15} />{t('login')}</Link>{demo ? <div className="demo-notice"><ShieldCheck size={16} />{t('demoNotice')}</div> : null}</div></div>;
}

export function ResetPasswordPage() {
  const { t } = useLocale(); const { updatePassword } = useAuth(); const { notify } = useToast(); const navigate = useNavigate();
  const [password, setPassword] = useState(''); const [confirm, setConfirm] = useState(''); const [error, setError] = useState(''); const [loading, setLoading] = useState(false);
  const submit = async (event: FormEvent) => { event.preventDefault(); if (password.length < 8) { setError(t('passwordMin')); return; } if (password !== confirm) { setError(t('passwordMismatch')); return; } setLoading(true); setError(''); try { await updatePassword(password); notify(t('saved')); navigate('/account'); } catch { setError(t('somethingWrong')); } finally { setLoading(false); } };
  return <div className="narrow-page page-container page-space"><div className="auth-simple-card"><span className="auth-simple-icon"><LockKeyhole size={22} /></span><div className="eyebrow">{t('password')}</div><h1>{t('forgotTitle')}</h1><form className="auth-form" onSubmit={submit}><TextField label={t('password')} type="password" required autoComplete="new-password" value={password} onChange={event => setPassword(event.target.value)} /><TextField label={t('confirmPassword')} type="password" required autoComplete="new-password" value={confirm} onChange={event => setConfirm(event.target.value)} />{error ? <div className="form-alert">{error}</div> : null}<Button size="lg" className="full-width" loading={loading}>{t('saveChanges')}</Button></form></div></div>;
}

export function VerificationPage() {
  const { t } = useLocale(); const [state, setState] = useState<'checking' | 'success' | 'error'>(isDemoMode ? 'success' : 'checking');
  useEffect(() => {
    if (isDemoMode || !supabase) return;
    const params = new URLSearchParams(window.location.search); const code = params.get('code'); const authError = params.get('error_description');
    if (authError) { setState('error'); return; }
    if (code) { void supabase.auth.exchangeCodeForSession(code).then(({ error }) => setState(error ? 'error' : 'success')); return; }
    if (window.location.hash.includes('access_token')) { setState('success'); return; }
    setState('error');
  }, []);
  return <div className="narrow-page page-container page-space"><div className="auth-simple-card verify-card"><span className={`auth-simple-icon ${state === 'error' ? 'error' : ''}`}>{state === 'checking' ? <MailCheck size={22} /> : state === 'success' ? <CheckCircle2 size={23} /> : <ShieldCheck size={22} />}</span><div className="eyebrow">{t('register')}</div><h1>{state === 'success' ? t('verifyDone') : state === 'error' ? t('verifyFailed') : t('loading')}</h1><p>{state === 'success' ? t('verifyBody') : state === 'error' ? t('verifyFailed') : t('loading')}</p>{state !== 'checking' ? <Link className="button button-primary button-lg" to="/login">{t('login')}</Link> : null}</div></div>;
}
