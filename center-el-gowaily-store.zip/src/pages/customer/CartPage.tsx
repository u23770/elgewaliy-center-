import { ArrowUpLeft, ShoppingBag, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../../contexts/CartContext';
import { useLocale } from '../../contexts/LocaleContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { getDeliveryEstimate, getStoreSettings } from '../../services/repository';
import { Button, EmptyState, ErrorState, PageHeader, QuantityStepper, Spinner } from '../../components/ui/primitives';
import { usePageMeta } from '../../hooks/usePageMeta';

export function CartPage() {
  const { t, localized, formatPrice } = useLocale();
  const { lines, subtotal, isLoading, setQuantity, removeItem } = useCart();
  const { data: settings, error, retry } = useAsyncData(getStoreSettings, []);
  usePageMeta(`${t('cart')} | ${t('brand')}`, t('orderSummary'));
  if (isLoading && !lines.length) return <div className="page-container page-space"><Spinner label={t('loading')} /></div>;
  return <div className="page-container page-space cart-page">
    <div className="cart-page-header"><PageHeader eyebrow={t('cart')} title={t('orderSummary')} description={t('checkoutBody')} /><span className="cart-items-count">{lines.reduce((sum, line) => sum + line.quantity, 0)} {t('products')}</span></div>
    {!lines.length ? <EmptyState icon={<ShoppingBag size={26} />} title={t('emptyBag')} description={t('emptyBagBody')} action={<Link className="button button-primary" to="/shop">{t('browsePieces')} <ArrowUpLeft size={16} /></Link>} /> : <div className="cart-page-layout">
      <div className="cart-items-list">
        {lines.map(line => <article className="cart-item" key={`${line.productId}-${line.variantId ?? 'simple'}`}>
          <Link to={`/product/${line.product.slug}`} className="cart-item-image"><img src={line.variant?.imageUrl ?? line.product.images[0]?.url ?? '/images/fallback.svg'} alt={localized(line.product.name)} /></Link>
          <div className="cart-item-main"><div className="cart-item-heading"><div><Link to={`/product/${line.product.slug}`} className="cart-item-name">{localized(line.product.name)}</Link><span className="cart-item-category">{localized(line.product.category)}</span></div><button className="remove-item-button" type="button" onClick={() => removeItem(line.productId, line.variantId)} aria-label={`${t('remove')} ${localized(line.product.name)}`}><Trash2 size={17} /></button></div>
            <div className="cart-item-attributes">{line.variant?.size ? <span>{t('size')}: {line.variant.size}</span> : null}{line.variant?.color ? <span><i style={{ backgroundColor: line.variant.color.hex }} />{localized(line.variant.color.name)}</span> : null}{line.product.variants.length && line.maxQuantity <= 0 ? <strong className="cart-out-stock">{t('soldOut')}</strong> : null}</div>
            <div className="cart-item-bottom"><QuantityStepper value={line.quantity} max={Math.max(1, line.maxQuantity)} onChange={value => setQuantity(line.productId, line.variantId, value)} label={t('quantity')} /><div className="cart-item-price"><span>{formatPrice(line.unitPrice)} <small>× {line.quantity}</small></span><strong>{formatPrice(line.lineTotal)}</strong></div></div>
          </div>
        </article>)}
        <Link to="/shop" className="continue-shopping-link"><ArrowUpLeft size={16} />{t('continueShopping')}</Link>
      </div>
      <aside className="cart-summary-card"><div className="summary-card-top"><span className="eyebrow">{t('secureCheckout')}</span><h2>{t('orderSummary')}</h2></div><div className="summary-rows"><div className="summary-row"><span>{t('subtotal')}</span><strong>{formatPrice(subtotal)}</strong></div>{error ? <ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /> : null}<div className="summary-row"><span>{t('delivery')}</span><strong>{settings ? (getDeliveryEstimate(subtotal, settings) === 0 ? t('free') : formatPrice(getDeliveryEstimate(subtotal, settings))) : t('deliveryAtCheckout')}</strong></div></div><div className="summary-total"><span>{t('total')}</span><strong>{formatPrice(subtotal + (settings ? getDeliveryEstimate(subtotal, settings) : 0))}</strong></div><p className="summary-note">{t('deliveryFeeNote')}</p><Link to="/checkout"><Button size="lg" className="full-width">{t('checkout')} <ArrowUpLeft size={17} /></Button></Link><div className="payment-trust"><span>✓</span>{t('cashOnDelivery')}</div></aside>
    </div>}
  </div>;
}
