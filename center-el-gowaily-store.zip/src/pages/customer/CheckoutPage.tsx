import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { ArrowUpLeft, Check, CreditCard, PackageCheck, ShieldCheck } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import type { AddressInput, CheckoutInput, PaymentMethod } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import { useLocale } from '../../contexts/LocaleContext';
import { useToast } from '../../contexts/ToastContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { createOrder, getDeliveryEstimate, getStoreSettings } from '../../services/repository';
import { Button, ErrorState, PageHeader, SelectField, Spinner, TextAreaField, TextField } from '../../components/ui/primitives';
import { usePageMeta } from '../../hooks/usePageMeta';

interface CheckoutForm { customerName: string; email: string; phone: string; governorate: string; area: string; address: string; notes: string }
const governorates = ['Cairo', 'Giza', 'Alexandria', 'Qalyubia', 'Dakahlia', 'Sharqia', 'Gharbia', 'Monufia', 'Beheira', 'Kafr El Sheikh', 'Faiyum', 'Beni Suef', 'Minya', 'Assiut', 'Sohag', 'Qena', 'Luxor', 'Aswan', 'Red Sea', 'Matrouh', 'North Sinai', 'South Sinai', 'New Valley', 'Port Said', 'Ismailia', 'Suez', 'Damietta'];
const governorateAr: Record<string, string> = { Cairo: 'القاهرة', Giza: 'الجيزة', Alexandria: 'الإسكندرية', Qalyubia: 'القليوبية', Dakahlia: 'الدقهلية', Sharqia: 'الشرقية', Gharbia: 'الغربية', Monufia: 'المنوفية', Beheira: 'البحيرة', 'Kafr El Sheikh': 'كفر الشيخ', Faiyum: 'الفيوم', 'Beni Suef': 'بني سويف', Minya: 'المنيا', Assiut: 'أسيوط', Sohag: 'سوهاج', Qena: 'قنا', Luxor: 'الأقصر', Aswan: 'أسوان', 'Red Sea': 'البحر الأحمر', Matrouh: 'مطروح', 'North Sinai': 'شمال سيناء', 'South Sinai': 'جنوب سيناء', 'New Valley': 'الوادي الجديد', 'Port Said': 'بورسعيد', Ismailia: 'الإسماعيلية', Suez: 'السويس', Damietta: 'دمياط' };

export function CheckoutPage() {
  const { t, formatPrice, locale } = useLocale();
  const { user } = useAuth();
  const { lines, subtotal, isLoading: cartLoading, clearCart } = useCart();
  const { notify } = useToast();
  const { data: settings, error: settingsError, retry: retrySettings } = useAsyncData(getStoreSettings, []);
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [payment, setPayment] = useState<PaymentMethod>('cash_on_delivery');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [form, setForm] = useState<CheckoutForm>({ customerName: user?.fullName ?? '', email: user?.email ?? '', phone: user?.phone ?? '', governorate: '', area: '', address: '', notes: '' });
  useEffect(() => { setForm(current => ({ ...current, customerName: current.customerName || user?.fullName || '', email: current.email || user?.email || '', phone: current.phone || user?.phone || '' })); }, [user]);
  usePageMeta(`${t('checkout')} | ${t('brand')}`, t('checkoutBody'));
  const delivery = settings ? getDeliveryEstimate(subtotal, settings) : 0;
  const total = subtotal + delivery;
  const orderItems = useMemo(() => lines.map(line => ({ productId: line.productId, variantId: line.variantId, quantity: line.quantity })), [lines]);
  if (cartLoading && !lines.length) return <div className="page-container page-space"><Spinner label={t('loading')} /></div>;
  if (!lines.length && !submitting) return <div className="page-container page-space"><PageHeader title={t('checkoutTitle')} /><div className="checkout-empty"><p>{t('emptyBagBody')}</p><Link className="button button-primary" to="/shop">{t('browsePieces')}</Link></div></div>;

  const setValue = (key: keyof CheckoutForm, value: string) => { setForm(current => ({ ...current, [key]: value })); setErrors(current => ({ ...current, [key]: '' })); };
  const validate = () => {
    const next: Record<string, string> = {};
    if (!form.customerName.trim()) next.customerName = t('required');
    if (!/^\+?\d[\d\s()-]{7,16}$/.test(form.phone.trim())) next.phone = t('invalidPhone');
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email.trim())) next.email = t('invalidEmail');
    if (!form.governorate) next.governorate = t('required');
    if (!form.area.trim()) next.area = t('required');
    if (!form.address.trim()) next.address = t('required');
    setErrors(next); return Object.keys(next).length === 0;
  };
  const continueToPayment = (event: FormEvent) => { event.preventDefault(); if (validate()) { setStep(2); setFormError(''); } };
  const placeOrder = async () => {
    setSubmitting(true); setFormError('');
    try {
      const address: AddressInput = { governorate: form.governorate, area: form.area.trim(), address: form.address.trim(), notes: form.notes.trim() };
      const payload: CheckoutInput = { customerName: form.customerName.trim(), email: form.email.trim(), phone: form.phone.trim(), address, paymentMethod: payment, items: orderItems, userId: user?.id ?? null };
      const order = await createOrder(payload);
      clearCart();
      navigate(`/order-success/${encodeURIComponent(order.orderNumber)}`, { state: { order } });
    } catch (error) {
      const message = error instanceof Error ? error.message : t('checkoutFailed');
      setFormError(message); notify(t('checkoutFailed'), 'error');
    } finally { setSubmitting(false); }
  };

  return <div className="page-container page-space checkout-page">
    <div className="checkout-page-heading"><PageHeader eyebrow={t('secureCheckout')} title={t('checkoutTitle')} description={t('checkoutBody')} /><div className="checkout-steps"><span className={step >= 1 ? 'active' : ''}><i>{step > 1 ? <Check size={14} /> : '01'}</i>{t('stepDetails')}</span><b /><span className={step >= 2 ? 'active' : ''}><i>02</i>{t('stepPayment')}</span></div></div>
    {settingsError ? <ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retrySettings} /> : null}
    <div className="checkout-layout">
      <div className="checkout-main-card">
        {step === 1 ? <form onSubmit={continueToPayment} noValidate>
          <div className="checkout-section-heading"><span className="checkout-step-no">01</span><div><h2>{t('stepDetails')}</h2><p>{locale === 'ar' ? 'أخبرنا أين نرسل اختياراتك.' : 'Tell us where to send your picks.'}</p></div></div>
          <div className="checkout-fields">
            <TextField label={t('customerName')} required autoComplete="name" value={form.customerName} onChange={event => setValue('customerName', event.target.value)} error={errors.customerName} />
            <TextField label={t('phone')} required type="tel" autoComplete="tel" value={form.phone} onChange={event => setValue('phone', event.target.value)} error={errors.phone} placeholder="01X XXX XXXX" />
            <TextField label={t('email')} type="email" autoComplete="email" value={form.email} onChange={event => setValue('email', event.target.value)} error={errors.email} />
            <SelectField label={t('governorate')} required value={form.governorate} onChange={event => setValue('governorate', event.target.value)} error={errors.governorate}><option value="">{t('chooseGovernorate')}</option>{governorates.map(value => <option key={value} value={value}>{locale === 'ar' ? governorateAr[value] : value}</option>)}</SelectField>
            <TextField label={t('area')} required autoComplete="address-level2" value={form.area} onChange={event => setValue('area', event.target.value)} error={errors.area} />
            <TextAreaField label={t('fullAddress')} required rows={3} autoComplete="street-address" value={form.address} onChange={event => setValue('address', event.target.value)} error={errors.address} className="checkout-full-field" />
            <TextAreaField label={t('notes')} rows={2} value={form.notes} onChange={event => setValue('notes', event.target.value)} className="checkout-full-field" />
          </div>
          <div className="checkout-form-actions"><Link to="/cart" className="text-link">{locale === 'ar' ? 'العودة للحقيبة' : 'Back to bag'}</Link><Button type="submit" size="lg">{t('continue')} <ArrowUpLeft size={17} /></Button></div>
        </form> : <div className="checkout-review">
          <div className="checkout-section-heading"><span className="checkout-step-no">02</span><div><h2>{t('stepPayment')}</h2><p>{locale === 'ar' ? 'راجع تفاصيلك واختر طريقة الدفع.' : 'Review your details and choose how to pay.'}</p></div></div>
          <div className="checkout-review-block"><div className="review-block-heading"><h3>{t('deliveryAddress')}</h3><button type="button" className="text-action" onClick={() => setStep(1)}>{t('edit')}</button></div><p><strong>{form.customerName}</strong> · {form.phone}</p><p>{form.address}, {form.area}, {locale === 'ar' ? governorateAr[form.governorate] : form.governorate}</p>{form.notes ? <p>{form.notes}</p> : null}</div>
          <fieldset className="payment-methods"><legend>{t('paymentMethod')}</legend><label className={`payment-option ${payment === 'cash_on_delivery' ? 'selected' : ''}`}><input type="radio" name="payment" checked={payment === 'cash_on_delivery'} onChange={() => setPayment('cash_on_delivery')} /><span className="payment-icon"><PackageCheck size={19} /></span><span><strong>{t('cashOnDelivery')}</strong><small>{locale === 'ar' ? 'ادفع نقدًا عند وصول طلبك' : 'Pay in cash when your order arrives'}</small></span><i className="radio-mark" /></label><label className={`payment-option ${payment === 'card_on_delivery' ? 'selected' : ''}`}><input type="radio" name="payment" checked={payment === 'card_on_delivery'} onChange={() => setPayment('card_on_delivery')} /><span className="payment-icon"><CreditCard size={19} /></span><span><strong>{t('cardOnDelivery')}</strong><small>{locale === 'ar' ? 'الدفع بالبطاقة إلى المندوب' : 'Pay by card to the courier'}</small></span><i className="radio-mark" /></label></fieldset>
          <div className="payment-reassurance"><ShieldCheck size={18} /><p>{t('noOnlinePayment')}</p></div>
          {formError ? <div className="form-alert" role="alert">{formError}</div> : null}
          <div className="checkout-form-actions"><Button variant="secondary" onClick={() => setStep(1)}>{t('back')}</Button><Button type="button" size="lg" loading={submitting} onClick={placeOrder}>{t('placeOrder')} <ArrowUpLeft size={17} /></Button></div>
        </div>}
      </div>
      <aside className="checkout-summary-card"><div className="summary-card-top"><span className="eyebrow">{t('orderSummary')}</span><h2>{lines.length} {t('products')}</h2></div><div className="checkout-summary-items">{lines.map(line => <div className="checkout-summary-item" key={`${line.productId}-${line.variantId ?? 'simple'}`}><div className="checkout-summary-image"><img src={line.product.images[0]?.url ?? '/images/fallback.svg'} alt="" /><i>{line.quantity}</i></div><div><strong>{locale === 'ar' ? line.product.name.ar : line.product.name.en}</strong><small>{line.variant?.size ?? ''}{line.variant?.color ? ` · ${locale === 'ar' ? line.variant.color.name.ar : line.variant.color.name.en}` : ''}</small></div><b>{formatPrice(line.lineTotal)}</b></div>)}</div><div className="summary-rows"><div className="summary-row"><span>{t('subtotal')}</span><strong>{formatPrice(subtotal)}</strong></div><div className="summary-row"><span>{t('delivery')}</span><strong>{delivery === 0 ? t('free') : formatPrice(delivery)}</strong></div></div><div className="summary-total"><span>{t('total')}</span><strong>{formatPrice(total)}</strong></div><p className="summary-note">{t('deliveryFeeNote')}</p></aside>
    </div>
  </div>;
}
