import { useState, type FormEvent } from 'react';
import { ArrowUpLeft, Check, ClipboardList, Search, ShieldCheck } from 'lucide-react';
import { Link, useLocation, useParams } from 'react-router-dom';
import type { Order, OrderStatus } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { useLocale } from '../../contexts/LocaleContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { getOrderById, listOrders, trackOrder } from '../../services/repository';
import { formatDate, paymentLabel } from '../../utils/format';
import { Button, EmptyState, ErrorState, OrderStatusBadge, PageHeader, Spinner, TextField } from '../../components/ui/primitives';
import { usePageMeta } from '../../hooks/usePageMeta';

const steps: OrderStatus[] = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered'];

export function OrderTimeline({ order }: { order: Order }) {
  const { t, locale } = useLocale();
  const currentIndex = steps.indexOf(order.status);
  const cancelled = order.status === 'cancelled';
  const labels: Record<OrderStatus, string> = {
    pending: t('pending'), confirmed: locale === 'ar' ? 'تم التأكيد' : 'Confirmed', preparing: locale === 'ar' ? 'جارٍ التجهيز' : 'Preparing',
    out_for_delivery: locale === 'ar' ? 'في الطريق إليك' : 'Out for delivery', delivered: locale === 'ar' ? 'تم التسليم' : 'Delivered', cancelled: locale === 'ar' ? 'تم إلغاء الطلب' : 'Cancelled',
  };
  const eventFor = (status: OrderStatus) => order.events.find(event => event.status === status);
  return <div className={`order-timeline ${cancelled ? 'timeline-cancelled' : ''}`}>
    {(cancelled ? ['pending', 'cancelled'] as OrderStatus[] : steps).map((status, index, list) => {
      const event = eventFor(status); const done = cancelled ? status === 'pending' || status === 'cancelled' : index <= currentIndex;
      return <div className={`timeline-item ${done ? 'done' : ''} ${status === order.status ? 'current' : ''}`} key={status}>
        <div className="timeline-indicator">{done ? <Check size={13} /> : <span />}</div>
        <div className="timeline-content"><strong>{labels[status]}</strong>{event ? <time>{formatDate(event.at, locale)}</time> : status === order.status ? <time>{formatDate(order.updatedAt, locale)}</time> : null}{event?.note ? <p>{event.note}</p> : null}</div>
        {index < list.length - 1 ? <span className="timeline-connector" /> : null}
      </div>;
    })}
  </div>;
}

export function OrderHistoryPage() {
  const { user } = useAuth(); const { t, formatPrice, locale } = useLocale();
  const { data: orderData, loading, error, retry } = useAsyncData(() => listOrders(user), [user?.id]);
  const orders = orderData ?? [];
  usePageMeta(`${t('orderHistory')} | ${t('brand')}`, t('orderHistory'));
  return <div className="account-page page-container page-space">
    <PageHeader eyebrow={t('account')} title={t('orderHistory')} description={t('noOrdersBody')} />
    {loading ? <div className="order-list-skeleton"><span className="skeleton skeleton-line" /><span className="skeleton skeleton-line" /><span className="skeleton skeleton-line" /></div> : error ? <ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /> : orders?.length ? <div className="order-list">{orders.map(order => <Link className="order-list-card" to={`/orders/${order.id}`} key={order.id}>
      <div className="order-list-top"><div><span className="eyebrow">{t('orderNumber')}</span><strong>{order.orderNumber}</strong></div><OrderStatusBadge status={order.status} /></div>
      <div className="order-list-meta"><span>{t('placedOn')} · {formatDate(order.createdAt, locale)}</span><span>{order.items.length} {t('products')}</span><strong>{formatPrice(order.total)}</strong></div>
      <span className="order-list-arrow"><ArrowUpLeft size={16} /></span>
    </Link>)}</div> : <EmptyState icon={<ClipboardList size={24} />} title={t('noOrders')} description={t('noOrdersBody')} action={<Link className="button button-primary" to="/shop">{t('shopNow')}</Link>} />}
  </div>;
}

export function OrderDetailPage() {
  const { id = '' } = useParams(); const { user } = useAuth(); const { t } = useLocale();
  const { data: order, loading, error, retry } = useAsyncData(() => getOrderById(id), [id]);
  usePageMeta(`${t('orderHistory')} | ${t('brand')}`, t('orderHistory'));
  if (loading) return <div className="page-container page-space"><Spinner label={t('loading')} /></div>;
  if (error) return <div className="page-container page-space"><ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /></div>;
  if (!order || (user?.role !== 'admin' && order.userId !== user?.id && order.customerEmail?.toLowerCase() !== user?.email.toLowerCase())) return <div className="page-container page-space"><EmptyState title={t('trackingNotFound')} action={<Link className="button button-primary" to="/orders">{t('orderHistory')}</Link>} /></div>;
  return <OrderDetailsView order={order} />;
}

function OrderDetailsView({ order }: { order: Order }) {
  const { t, localized, formatPrice, locale } = useLocale();
  return <div className="page-container page-space order-detail-page">
    <div className="shop-breadcrumb"><Link to="/">{t('home')}</Link><span>/</span><Link to="/orders">{t('orderHistory')}</Link><span>/</span>{order.orderNumber}</div>
    <PageHeader eyebrow={t('orderNumber')} title={order.orderNumber} description={`${t('placedOn')} · ${formatDate(order.createdAt, locale)}`} actions={<OrderStatusBadge status={order.status} />} />
    <div className="order-detail-layout">
      <div className="order-detail-main"><section className="order-detail-card"><h2>{t('orderStatus')}</h2><OrderTimeline order={order} /></section><section className="order-detail-card"><h2>{t('orderItems')}</h2>{order.items.map(item => <div className="order-item-row" key={item.id}><div className="order-item-image"><img src={item.image ?? '/images/fallback.svg'} alt={localized(item.productName)} /></div><div className="order-item-info"><strong>{localized(item.productName)}</strong><span>{item.size ? `${t('size')}: ${item.size}` : ''}{item.color ? ` · ${localized(item.color.name)}` : ''}</span><small>{formatPrice(item.unitPrice)} × {item.quantity}</small></div><strong>{formatPrice(item.total)}</strong></div>)}</section></div>
      <aside className="order-detail-aside"><section className="order-detail-card"><h2>{t('deliveryAddress')}</h2><strong>{order.customerName}</strong><p>{order.phone}</p><p>{order.address.address}</p><p>{order.address.area}, {order.address.governorate}</p>{order.address.notes ? <p>{order.address.notes}</p> : null}</section><section className="order-detail-card"><h2>{t('orderSummary')}</h2><div className="summary-row"><span>{t('subtotal')}</span><strong>{formatPrice(order.subtotal)}</strong></div><div className="summary-row"><span>{t('delivery')}</span><strong>{order.deliveryFee === 0 ? t('free') : formatPrice(order.deliveryFee)}</strong></div><div className="summary-row"><span>{t('payment')}</span><strong>{paymentLabel(order.paymentMethod, locale)}</strong></div><div className="summary-total"><span>{t('total')}</span><strong>{formatPrice(order.total)}</strong></div></section></aside>
    </div>
  </div>;
}

export function OrderSuccessPage() {
  const { orderNumber = '' } = useParams();
  const location = useLocation();
  const { t, localized, formatPrice, locale } = useLocale();
  const stateOrder = (location.state as { order?: Order } | null)?.order ?? null;
  const [phone, setPhone] = useState(''); const [found, setFound] = useState<Order | null>(stateOrder); const [error, setError] = useState(''); const [loading, setLoading] = useState(false);
  usePageMeta(`${t('orderPlaced')} | ${t('brand')}`, t('orderPlacedBody'));
  const lookup = async (event: FormEvent) => {
    event.preventDefault(); setLoading(true); setError('');
    try { const value = await trackOrder(decodeURIComponent(orderNumber), phone); if (!value) setError(t('trackingNotFound')); else setFound(value); }
    catch { setError(t('networkError')); } finally { setLoading(false); }
  };
  if (!found) return <div className="page-container page-space success-page"><div className="success-card"><span className="success-mark"><Check size={28} /></span><div className="eyebrow">{t('orderNumber')} · {decodeURIComponent(orderNumber)}</div><h1>{t('orderPlaced')}</h1><p>{t('orderPlacedBody')}</p><form className="success-lookup" onSubmit={lookup}><p>{t('trackingPrivacy')}</p><TextField label={t('phone')} required type="tel" value={phone} onChange={event => setPhone(event.target.value)} /><Button type="submit" loading={loading}>{t('viewOrder')}</Button>{error ? <div className="field-error" role="alert">{error}</div> : null}</form><Link to="/shop" className="text-link">{t('continueShopping')} <ArrowUpLeft size={15} /></Link></div></div>;
  return <div className="page-container page-space success-page"><div className="success-card"><span className="success-mark"><Check size={28} /></span><div className="eyebrow">{t('orderNumber')} · {found.orderNumber}</div><h1>{t('orderPlaced')}</h1><p>{t('orderPlacedBody')}</p><div className="success-order-summary"><div>{found.items.slice(0, 3).map(item => <img key={item.id} src={item.image ?? '/images/fallback.svg'} alt={localized(item.productName)} />)}</div><span>{found.items.length} {t('products')}</span><strong>{formatPrice(found.total)}</strong></div><div className="success-actions"><Link className="button button-primary button-lg" to={`/track/${encodeURIComponent(found.orderNumber)}`}>{t('trackOrder')} <ArrowUpLeft size={17} /></Link><Link className="button button-secondary button-lg" to="/shop">{t('continueShopping')}</Link></div><p className="success-customer">{found.customerName} · {formatDate(found.createdAt, locale)}</p></div></div>;
}

export function OrderTrackingPage() {
  const { orderNumber: routeOrder = '' } = useParams();
  const { t, localized, formatPrice, locale } = useLocale();
  const [orderNumber, setOrderNumber] = useState(decodeURIComponent(routeOrder)); const [phone, setPhone] = useState(''); const [order, setOrder] = useState<Order | null>(null); const [loading, setLoading] = useState(false); const [error, setError] = useState('');
  const lookup = async (event: FormEvent) => {
    event.preventDefault(); setLoading(true); setError(''); setOrder(null);
    try { const result = await trackOrder(orderNumber.trim(), phone.trim()); if (!result) setError(t('trackingNotFound')); else setOrder(result); }
    catch { setError(t('networkError')); } finally { setLoading(false); }
  };
  usePageMeta(`${t('trackOrder')} | ${t('brand')}`, t('trackingTitle'));
  return <div className="page-container page-space tracking-page"><PageHeader eyebrow={t('trackOrder')} title={t('trackingTitle')} description={t('trackSearchHint')} />
    <form className="tracking-form" onSubmit={lookup}><TextField label={t('orderNumber')} required value={orderNumber} onChange={event => setOrderNumber(event.target.value)} placeholder="EG-20261005-ABCD" /><TextField label={t('phone')} required type="tel" value={phone} onChange={event => setPhone(event.target.value)} placeholder="01X XXX XXXX" /><Button size="lg" type="submit" loading={loading}><Search size={17} />{t('lookupOrder')}</Button></form>
    <p className="tracking-privacy"><ShieldCheck size={16} />{t('trackingPrivacy')}</p>
    {error ? <div className="form-alert tracking-alert" role="alert">{error}</div> : null}
    {order ? <div className="tracking-result"><div className="tracking-result-head"><div><span className="eyebrow">{t('orderNumber')}</span><h2>{order.orderNumber}</h2><p>{t('placedOn')} · {formatDate(order.createdAt, locale)}</p></div><OrderStatusBadge status={order.status} /></div><div className="tracking-result-grid"><section className="order-detail-card"><h3>{t('orderStatus')}</h3><OrderTimeline order={order} /></section><section className="order-detail-card"><h3>{t('orderItems')}</h3>{order.items.map(item => <div className="order-item-row" key={item.id}><div className="order-item-image"><img src={item.image ?? '/images/fallback.svg'} alt={localized(item.productName)} /></div><div className="order-item-info"><strong>{localized(item.productName)}</strong><span>{item.size ? `${t('size')}: ${item.size}` : ''}{item.color ? ` · ${localized(item.color.name)}` : ''}</span><small>{formatPrice(item.unitPrice)} × {item.quantity}</small></div><strong>{formatPrice(item.total)}</strong></div>)}<div className="summary-total"><span>{t('total')}</span><strong>{formatPrice(order.total)}</strong></div></section></div></div> : null}
  </div>;
}
