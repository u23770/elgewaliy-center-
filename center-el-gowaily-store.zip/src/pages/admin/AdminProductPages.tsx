import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import { ArrowUpLeft, ImagePlus, Plus, Trash2, Upload } from 'lucide-react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import type { Category, Product, ProductColor, ProductImage, ProductVariant } from '../../types';
import { useLocale } from '../../contexts/LocaleContext';
import { useToast } from '../../contexts/ToastContext';
import { useAsyncData } from '../../hooks/useAsyncData';
import { listCategories, listProducts, listSizes, listColors, saveProduct, uploadProductImage } from '../../services/repository';
import { colorKey, makeSlug } from '../../utils/format';
import { Button, ErrorState, PageHeader, SelectField, Spinner, TextAreaField, TextField } from '../../components/ui/primitives';

interface DraftVariant { id: string; sku: string; size: string; colorEn: string; colorAr: string; colorHex: string; stock: number; priceOverride: string; active: boolean }
interface DraftImage { id: string; url: string; altEn: string; altAr: string; colorKey: string }
interface Draft { id: string; nameEn: string; nameAr: string; slug: string; descriptionEn: string; descriptionAr: string; categoryId: string; price: string; salePrice: string; sku: string; active: boolean; featured: boolean; stock: string; hasVariants: boolean; variants: DraftVariant[]; images: DraftImage[]; createdAt: string }
const blankDraft = (): Draft => ({ id: '', nameEn: '', nameAr: '', slug: '', descriptionEn: '', descriptionAr: '', categoryId: '', price: '', salePrice: '', sku: '', active: true, featured: false, stock: '0', hasVariants: false, variants: [], images: [], createdAt: new Date().toISOString() });
const draftFromProduct = (product: Product): Draft => ({
  id: product.id, nameEn: product.name.en, nameAr: product.name.ar, slug: product.slug, descriptionEn: product.description.en,
  descriptionAr: product.description.ar, categoryId: product.categoryId, price: String(product.price), salePrice: product.salePrice ? String(product.salePrice) : '',
  sku: product.sku, active: product.active, featured: product.featured, stock: String(product.stock), hasVariants: product.variants.length > 0,
  variants: product.variants.map(variant => ({ id: variant.id, sku: variant.sku ?? '', size: variant.size ?? '', colorEn: variant.color?.name.en ?? '', colorAr: variant.color?.name.ar ?? '', colorHex: variant.color?.hex ?? '#7a8061', stock: variant.stock, priceOverride: variant.priceOverride ? String(variant.priceOverride) : '', active: variant.active })),
  images: product.images.map(image => ({ id: image.id, url: image.url, altEn: image.alt.en, altAr: image.alt.ar, colorKey: image.colorKey ?? '' })), createdAt: product.createdAt,
});

export function AdminProductFormPage() {
  const { id } = useParams(); const editing = Boolean(id && id !== 'new');
  const { t, localized } = useLocale(); const { notify } = useToast(); const navigate = useNavigate();
  const { data: allProducts, loading: productsLoading, error: productsError, retry } = useAsyncData(() => editing ? listProducts({ includeInactive: true }) : Promise.resolve([]), [id]);
  const { data: categoriesData } = useAsyncData(listCategories, []);
  const categories = categoriesData ?? [];
  const { data: sizesData } = useAsyncData(listSizes, []);
  const { data: colorsData } = useAsyncData(listColors, []);
  const sizes = sizesData ?? [];
  const colors = colorsData ?? [];
  const [draft, setDraft] = useState<Draft>(() => blankDraft()); const [initialized, setInitialized] = useState(!editing); const [saving, setSaving] = useState(false); const [uploading, setUploading] = useState(false); const [errorText, setErrorText] = useState('');
  const currentProduct = allProducts?.find(product => product.id === id);
  useEffect(() => {
    if (!editing) { setDraft(blankDraft()); setInitialized(true); return; }
    if (currentProduct) { setDraft(draftFromProduct(currentProduct)); setInitialized(true); }
  }, [editing, currentProduct?.id]);
  const categoryList = categories ?? [];
  const categoryOptions = useMemo(() => categoryList.filter((category: Category) => category.active), [categoryList]);
  const set = <K extends keyof Draft>(key: K, value: Draft[K]) => setDraft(current => ({ ...current, [key]: value }));
  const setVariant = (index: number, key: keyof DraftVariant, value: string | number | boolean) => setDraft(current => ({ ...current, variants: current.variants.map((variant, i) => i === index ? { ...variant, [key]: value } : variant) }));
  const addVariant = () => setDraft(current => ({ ...current, hasVariants: true, variants: [...current.variants, { id: `new-${crypto.randomUUID()}`, sku: '', size: '', colorEn: '', colorAr: '', colorHex: '#7a8061', stock: 0, priceOverride: '', active: true }] }));
  const addImage = () => setDraft(current => ({ ...current, images: [...current.images, { id: `image-${crypto.randomUUID()}`, url: '', altEn: current.nameEn, altAr: current.nameAr, colorKey: '' }] }));
  const updateImage = (index: number, key: keyof DraftImage, value: string) => setDraft(current => ({ ...current, images: current.images.map((image, i) => i === index ? { ...image, [key]: value } : image) }));
  const upload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; if (!file) return;
    if (!file.type.startsWith('image/')) { notify(t('somethingWrong'), 'error'); return; }
    setUploading(true);
    try { const url = await uploadProductImage(file); setDraft(current => ({ ...current, images: [...current.images, { id: `image-${crypto.randomUUID()}`, url, altEn: current.nameEn, altAr: current.nameAr, colorKey: '' }] })); notify(t('saved')); }
    catch { notify(t('somethingWrong'), 'error'); }
    finally { setUploading(false); event.target.value = ''; }
  };
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setErrorText('');
    const price = Number(draft.price); const salePrice = draft.salePrice ? Number(draft.salePrice) : null;
    if (!draft.nameEn.trim() || !draft.nameAr.trim() || !draft.sku.trim() || !draft.categoryId || !Number.isFinite(price) || price <= 0) { setErrorText(t('required')); return; }
    if (salePrice !== null && (!Number.isFinite(salePrice) || salePrice < 0 || salePrice >= price)) { setErrorText(t('somethingWrong')); return; }
    if (draft.hasVariants && !draft.variants.length) { setErrorText(t('required')); return; }
    if (draft.variants.some(variant => variant.stock < 0 || !Number.isInteger(Number(variant.stock)))) { setErrorText(t('somethingWrong')); return; }
    const variantKeys = draft.variants.map(variant => `${variant.size.trim().toLowerCase()}::${colorKey(variant.colorEn || variant.colorAr)}`);
    if (new Set(variantKeys).size !== variantKeys.length) { setErrorText(t('somethingWrong')); return; }
    const variants: ProductVariant[] = draft.hasVariants ? draft.variants.map(variant => {
      const color: ProductColor | undefined = variant.colorEn.trim() || variant.colorAr.trim() ? { key: colorKey(variant.colorEn || variant.colorAr), name: { en: variant.colorEn.trim(), ar: variant.colorAr.trim() }, hex: variant.colorHex } : undefined;
      return { id: variant.id.startsWith('new-') ? '' : variant.id, sku: variant.sku.trim() || undefined, size: variant.size.trim() || undefined, color, stock: Number(variant.stock), priceOverride: variant.priceOverride ? Number(variant.priceOverride) : null, active: variant.active };
    }) : [];
    const images: ProductImage[] = draft.images.filter(image => image.url.trim()).map(image => ({ id: image.id, url: image.url.trim(), alt: { en: image.altEn || draft.nameEn, ar: image.altAr || draft.nameAr }, colorKey: image.colorKey.trim() || undefined }));
    const product: Product = {
      id: draft.id, slug: draft.slug.trim() || makeSlug(draft.nameEn), name: { en: draft.nameEn.trim(), ar: draft.nameAr.trim() },
      description: { en: draft.descriptionEn.trim(), ar: draft.descriptionAr.trim() }, categoryId: draft.categoryId,
      category: categoryList.find((category: Category) => category.id === draft.categoryId)?.name, images,
      price, salePrice, sku: draft.sku.trim(), active: draft.active, featured: draft.featured,
      stock: draft.hasVariants ? 0 : Number(draft.stock), variants, createdAt: draft.createdAt, updatedAt: new Date().toISOString(),
    };
    setSaving(true);
    try { const saved = await saveProduct(product); notify(t('productSaved')); navigate(`/admin/products/${saved.id}/edit`, { replace: true }); }
    catch { setErrorText(t('somethingWrong')); notify(t('somethingWrong'), 'error'); }
    finally { setSaving(false); }
  };

  if (productsLoading || (editing && !initialized)) return <div className="admin-page"><Spinner label={t('loading')} /></div>;
  if (productsError) return <div className="admin-page"><ErrorState title={t('somethingWrong')} description={t('networkError')} onRetry={retry} /></div>;
  if (editing && !currentProduct) return <div className="admin-page"><ErrorState title={t('productNotFound')} description={t('noProductsBody')} onRetry={retry} /></div>;
  return <div className="admin-page admin-product-form-page">
    <div className="admin-back-link"><Link to="/admin/products"><ArrowUpLeft size={15} />{t('adminProducts')}</Link></div>
    <PageHeader eyebrow={editing ? t('editProduct') : t('addProduct')} title={editing ? t('editProduct') : t('addProduct')} description={t('productVariants')} />
    <form className="admin-product-form" onSubmit={submit} noValidate>
      <section className="admin-panel form-panel"><div className="admin-panel-header"><div><span className="eyebrow">01</span><h2>{t('products')}</h2></div></div><div className="admin-form-grid">
        <TextField label={t('productNameEn')} required value={draft.nameEn} onChange={event => set('nameEn', event.target.value)} />
        <TextField label={t('productNameAr')} required value={draft.nameAr} onChange={event => set('nameAr', event.target.value)} />
        <TextField label={t('productSku')} required value={draft.sku} onChange={event => set('sku', event.target.value)} />
        <TextField label={t('categorySlug')} value={draft.slug} onChange={event => set('slug', event.target.value)} hint={draft.slug ? `/product/${draft.slug}` : draft.nameEn ? `/product/${makeSlug(draft.nameEn)}` : ''} />
        <SelectField label={t('productCategory')} required value={draft.categoryId} onChange={event => set('categoryId', event.target.value)}><option value="">{t('allCategories')}</option>{categoryOptions.map((category: Category) => <option key={category.id} value={category.id}>{localized(category.name)}</option>)}</SelectField>
        <TextField label={t('productPrice')} required type="number" min="1" step="1" value={draft.price} onChange={event => set('price', event.target.value)} />
        <TextField label={t('salePrice')} type="number" min="0" step="1" value={draft.salePrice} onChange={event => set('salePrice', event.target.value)} />
        <TextAreaField label={t('descriptionEn')} rows={4} value={draft.descriptionEn} onChange={event => set('descriptionEn', event.target.value)} className="admin-span-two" />
        <TextAreaField label={t('descriptionAr')} rows={4} value={draft.descriptionAr} onChange={event => set('descriptionAr', event.target.value)} className="admin-span-two" />
      </div><div className="admin-toggle-row"><label><input type="checkbox" checked={draft.active} onChange={event => set('active', event.target.checked)} /><span>{t('productActive')}</span></label><label><input type="checkbox" checked={draft.featured} onChange={event => set('featured', event.target.checked)} /><span>{t('featuredProduct')}</span></label></div></section>

      <section className="admin-panel form-panel"><div className="admin-panel-header"><div><span className="eyebrow">02</span><h2>{t('productImages')}</h2></div><div className="form-panel-actions"><label className="button button-secondary button-sm upload-button"><Upload size={15} />{uploading ? t('loading') : t('uploadImage')}<input type="file" accept="image/*" onChange={upload} disabled={uploading} /></label><Button type="button" size="sm" variant="ghost" onClick={addImage}><Plus size={15} />{t('imageUrl')}</Button></div></div>
        {draft.images.length ? <div className="admin-image-list">{draft.images.map((image, index) => <div className="admin-image-editor" key={image.id}><img src={image.url || '/images/fallback.svg'} alt="" onError={event => { event.currentTarget.src = '/images/fallback.svg'; }} /><div className="admin-form-grid"><TextField label={t('imageUrl')} value={image.url} onChange={event => updateImage(index, 'url', event.target.value)} className="admin-span-two" /><TextField label={t('productNameEn')} value={image.altEn} onChange={event => updateImage(index, 'altEn', event.target.value)} /><TextField label={t('productNameAr')} value={image.altAr} onChange={event => updateImage(index, 'altAr', event.target.value)} /><TextField label={t('color')} value={image.colorKey} onChange={event => updateImage(index, 'colorKey', event.target.value)} /></div><button type="button" className="icon-button danger-icon" aria-label={t('remove')} onClick={() => setDraft(current => ({ ...current, images: current.images.filter((_, i) => i !== index) }))}><Trash2 size={16} /></button></div>)}</div> : <div className="image-empty"><ImagePlus size={25} /><strong>{t('productImages')}</strong><span>{t('imageUrl')}</span></div>}
      </section>

      <section className="admin-panel form-panel"><div className="admin-panel-header"><div><span className="eyebrow">03</span><h2>{t('productVariants')}</h2></div><Button type="button" variant="secondary" size="sm" onClick={addVariant}><Plus size={15} />{t('addVariant')}</Button></div>
        <label className="variant-mode-toggle"><input type="checkbox" checked={draft.hasVariants} onChange={event => setDraft(current => ({ ...current, hasVariants: event.target.checked, variants: event.target.checked ? (current.variants.length ? current.variants : [{ id: `new-${crypto.randomUUID()}`, sku: '', size: '', colorEn: '', colorAr: '', colorHex: '#7a8061', stock: 0, priceOverride: '', active: true }]) : [] }))} /><span>{t('productVariants')}</span><small>{t('noVariants')}</small></label>
        {draft.hasVariants ? <><datalist id="admin-variant-sizes">{sizes.map(option => <option key={option.id} value={option.label} />)}</datalist><datalist id="admin-variant-colors-en">{colors.map(option => <option key={option.id} value={option.name.en} />)}</datalist><datalist id="admin-variant-colors-ar">{colors.map(option => <option key={option.id} value={option.name.ar} />)}</datalist><div className="variant-editor-list">{draft.variants.map((variant, index) => <div className="variant-editor-row" key={variant.id}><div className="variant-editor-title"><span>{t('variant')} {String(index + 1).padStart(2, '0')}</span><button type="button" className="icon-button danger-icon" aria-label={t('remove')} onClick={() => setDraft(current => ({ ...current, variants: current.variants.filter((_, i) => i !== index) }))}><Trash2 size={15} /></button></div><div className="admin-form-grid variant-editor-fields"><TextField label={t('variantSku')} value={variant.sku} onChange={event => setVariant(index, 'sku', event.target.value)} /><TextField label={t('variantSize')} list="admin-variant-sizes" value={variant.size} onChange={event => setVariant(index, 'size', event.target.value)} /><TextField label={t('variantColorEn')} list="admin-variant-colors-en" value={variant.colorEn} onChange={event => setVariant(index, 'colorEn', event.target.value)} /><TextField label={t('variantColorAr')} list="admin-variant-colors-ar" value={variant.colorAr} onChange={event => setVariant(index, 'colorAr', event.target.value)} /><TextField label={t('variantStock')} type="number" min="0" step="1" value={variant.stock} onChange={event => setVariant(index, 'stock', Number(event.target.value))} /><TextField label={t('salePrice')} type="number" min="0" step="1" value={variant.priceOverride} onChange={event => setVariant(index, 'priceOverride', event.target.value)} /><label className="color-picker-field"><span>{t('variantHex')}</span><input type="color" value={variant.colorHex} onChange={event => setVariant(index, 'colorHex', event.target.value)} /></label></div></div>)}</div></> : <TextField label={t('simpleStock')} type="number" min="0" step="1" value={draft.stock} onChange={event => set('stock', event.target.value)} className="simple-stock-field" />}
      </section>
      {errorText ? <div className="form-alert" role="alert">{errorText}</div> : null}
      <div className="product-form-actions"><Link to="/admin/products" className="button button-secondary">{t('cancel')}</Link><Button type="submit" size="lg" loading={saving}>{t('saveProduct')} <ArrowUpLeft size={17} /></Button></div>
    </form>
  </div>;
}
