import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { CustomerProfile } from '../types';
import type { Session } from '@supabase/supabase-js';
import { getDemoUsers, saveDemoUsers, type DemoUserRecord } from '../services/repository';
import { isDemoMode, supabase } from '../services/supabase';
import { readStorage, removeStorage, writeStorage } from '../utils/storage';

interface AuthContextValue {
  user: CustomerProfile | null;
  isLoading: boolean;
  isDemoMode: boolean;
  signIn: (email: string, password: string, adminOnly?: boolean) => Promise<void>;
  signUp: (name: string, email: string, password: string, phone?: string) => Promise<{ needsVerification: boolean }>;
  signOut: () => Promise<void>;
  updateProfile: (data: { fullName: string; phone?: string }) => Promise<void>;
  requestPasswordReset: (email: string) => Promise<void>;
  updatePassword: (password: string) => Promise<void>;
}
const AuthContext = createContext<AuthContextValue | null>(null);
const SESSION_KEY = 'ceg.demo.session';
const ADMIN_EMAIL = (import.meta.env.VITE_DEMO_ADMIN_EMAIL as string | undefined) || 'admin@centerelgowaily.demo';
const ADMIN_PASSWORD = (import.meta.env.VITE_DEMO_ADMIN_PASSWORD as string | undefined) || 'CenterDemo!2026';

async function passwordHash(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}
async function profileFor(id: string, email: string, metadata?: Record<string, unknown>): Promise<CustomerProfile> {
  const { data } = await supabase!.from('profiles').select('id,email,full_name,phone,role,created_at').eq('id', id).maybeSingle();
  if (data) return { id: data.id, email: data.email ?? email, fullName: data.full_name ?? '', phone: data.phone ?? '', role: data.role ?? 'customer', createdAt: data.created_at };
  return { id, email, fullName: String(metadata?.full_name ?? ''), phone: String(metadata?.phone ?? ''), role: 'customer' };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<CustomerProfile | null>(() => isDemoMode ? readStorage<CustomerProfile | null>(SESSION_KEY, null) : null);
  const [isLoading, setIsLoading] = useState(!isDemoMode);

  useEffect(() => {
    if (isDemoMode || !supabase) { setIsLoading(false); return; }
    let mounted = true;
    const hydrate = async (session: Session | null) => {
      if (!mounted) return;
      if (!session?.user) { setUser(null); setIsLoading(false); return; }
      try {
        const next = await profileFor(session.user.id, session.user.email ?? '', session.user.user_metadata);
        if (mounted) setUser(next);
      } catch {
        if (mounted) setUser({ id: session.user.id, email: session.user.email ?? '', fullName: '', role: 'customer' });
      } finally { if (mounted) setIsLoading(false); }
    };
    void supabase.auth.getSession().then(({ data }) => hydrate(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { setIsLoading(true); void hydrate(session); });
    return () => { mounted = false; listener.subscription.unsubscribe(); };
  }, []);

  const signIn = useCallback(async (email: string, password: string, adminOnly = false) => {
    const normalized = email.trim().toLowerCase();
    if (isDemoMode) {
      let next: CustomerProfile | null = null;
      if (normalized === ADMIN_EMAIL.toLowerCase() && password === ADMIN_PASSWORD) {
        next = { id: 'demo-admin', email: normalized, fullName: 'Store admin', role: 'admin' };
      } else {
        const candidateHash = await passwordHash(password);
        const record = getDemoUsers().find(value => value.email.toLowerCase() === normalized && value.passwordHash === candidateHash);
        if (record) next = { id: record.id, email: record.email, fullName: record.fullName, phone: record.phone, role: record.role };
      }
      if (!next || (adminOnly && next.role !== 'admin')) throw new Error('Invalid credentials or insufficient role.');
      writeStorage(SESSION_KEY, next); setUser(next); return;
    }
    const { data, error } = await supabase!.auth.signInWithPassword({ email: normalized, password });
    if (error || !data.user) throw error ?? new Error('Unable to sign in.');
    const next = await profileFor(data.user.id, data.user.email ?? normalized, data.user.user_metadata);
    if (adminOnly && next.role !== 'admin') { await supabase!.auth.signOut(); throw new Error('Administrator access required.'); }
    setUser(next);
  }, []);

  const signUp = useCallback(async (name: string, email: string, password: string, phone?: string) => {
    const normalized = email.trim().toLowerCase();
    if (isDemoMode) {
      const users = getDemoUsers();
      if (users.some(item => item.email.toLowerCase() === normalized)) throw new Error('Email already registered.');
      const created: DemoUserRecord = { id: `demo-${crypto.randomUUID()}`, email: normalized, fullName: name.trim(), phone: phone ?? '', role: 'customer', passwordHash: await passwordHash(password), createdAt: new Date().toISOString() };
      saveDemoUsers([...users, created]);
      const profile: CustomerProfile = { id: created.id, email: created.email, fullName: created.fullName, phone: created.phone, role: 'customer' };
      writeStorage(SESSION_KEY, profile); setUser(profile); return { needsVerification: false };
    }
    const { data, error } = await supabase!.auth.signUp({
      email: normalized, password,
      options: { data: { full_name: name.trim(), phone: phone ?? '' }, emailRedirectTo: `${window.location.origin}/auth/verify` },
    });
    if (error) throw error;
    if (data.user && data.session) setUser(await profileFor(data.user.id, normalized, data.user.user_metadata));
    return { needsVerification: !data.session };
  }, []);

  const signOut = useCallback(async () => {
    if (isDemoMode) { removeStorage(SESSION_KEY); setUser(null); return; }
    const { error } = await supabase!.auth.signOut(); if (error) throw error; setUser(null);
  }, []);

  const updateProfile = useCallback(async (data: { fullName: string; phone?: string }) => {
    if (!user) throw new Error('Please sign in.');
    if (isDemoMode) {
      const next = { ...user, fullName: data.fullName.trim(), phone: data.phone?.trim() ?? '' };
      if (user.role === 'customer') saveDemoUsers(getDemoUsers().map(record => record.id === user.id ? { ...record, fullName: next.fullName, phone: next.phone } : record));
      writeStorage(SESSION_KEY, next); setUser(next); return;
    }
    const { error } = await supabase!.from('profiles').update({ full_name: data.fullName.trim(), phone: data.phone?.trim() ?? '' }).eq('id', user.id);
    if (error) throw error;
    setUser(current => current ? { ...current, fullName: data.fullName.trim(), phone: data.phone?.trim() ?? '' } : current);
  }, [user]);

  const requestPasswordReset = useCallback(async (email: string) => {
    if (isDemoMode) return;
    const { error } = await supabase!.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/password/reset` });
    if (error) throw error;
  }, []);
  const updatePassword = useCallback(async (password: string) => {
    if (isDemoMode) throw new Error('Password reset is available after Supabase is configured.');
    const { error } = await supabase!.auth.updateUser({ password }); if (error) throw error;
  }, []);

  const value = useMemo(() => ({ user, isLoading, isDemoMode, signIn, signUp, signOut, updateProfile, requestPasswordReset, updatePassword }), [user, isLoading, signIn, signUp, signOut, updateProfile, requestPasswordReset, updatePassword]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
}
