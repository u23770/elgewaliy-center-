import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Locale, LocalizedText } from '../types';
import { messages, type TranslationKey } from '../i18n/messages';
import { readStorage, writeStorage } from '../utils/storage';

interface LocaleContextValue {
  locale: Locale;
  dir: 'rtl' | 'ltr';
  toggleLocale: () => void;
  setLocale: (locale: Locale) => void;
  t: (key: TranslationKey) => string;
  localized: (value: LocalizedText | undefined, fallback?: string) => string;
  formatPrice: (amount: number) => string;
}
const LocaleContext = createContext<LocaleContextValue | null>(null);

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => readStorage<Locale>('ceg.locale', 'ar'));
  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next);
    writeStorage('ceg.locale', next);
  }, []);
  const toggleLocale = useCallback(() => setLocale(locale === 'ar' ? 'en' : 'ar'), [locale, setLocale]);
  useEffect(() => {
    document.documentElement.lang = locale === 'ar' ? 'ar-EG' : 'en';
    document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr';
  }, [locale]);
  const t = useCallback((key: TranslationKey) => messages[locale][key] ?? key, [locale]);
  const localized = useCallback((value: LocalizedText | undefined, fallback = '') => value?.[locale] || value?.en || fallback, [locale]);
  const formatPrice = useCallback((amount: number) => new Intl.NumberFormat(locale === 'ar' ? 'ar-EG' : 'en-EG', {
    style: 'currency', currency: 'EGP', maximumFractionDigits: 0,
  }).format(Number.isFinite(amount) ? amount : 0), [locale]);
  const value = useMemo(() => ({ locale, dir: locale === 'ar' ? 'rtl' as const : 'ltr' as const, toggleLocale, setLocale, t, localized, formatPrice }), [locale, toggleLocale, setLocale, t, localized, formatPrice]);
  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useLocale() {
  const value = useContext(LocaleContext);
  if (!value) throw new Error('useLocale must be used inside LocaleProvider');
  return value;
}
