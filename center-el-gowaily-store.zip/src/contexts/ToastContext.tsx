import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { Check, CircleAlert, Info, X } from 'lucide-react';

type ToastKind = 'success' | 'error' | 'info';
interface ToastItem { id: number; message: string; kind: ToastKind }
interface ToastContextValue { notify: (message: string, kind?: ToastKind) => void }
const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const notify = useCallback((message: string, kind: ToastKind = 'success') => {
    const id = Date.now() + Math.random();
    setItems(current => [...current, { id, message, kind }]);
    window.setTimeout(() => setItems(current => current.filter(item => item.id !== id)), 3600);
  }, []);
  const value = useMemo(() => ({ notify }), [notify]);
  return <ToastContext.Provider value={value}>
    {children}
    <div className="toast-viewport" role="region" aria-live="polite" aria-label="Notifications">
      {items.map(item => <div className={`toast toast-${item.kind}`} key={item.id} role={item.kind === 'error' ? 'alert' : 'status'}>
        <span className="toast-mark">{item.kind === 'success' ? <Check size={17} /> : item.kind === 'error' ? <CircleAlert size={17} /> : <Info size={17} />}</span>
        <span>{item.message}</span>
        <button className="toast-close" type="button" aria-label="Dismiss notification" onClick={() => setItems(current => current.filter(value => value.id !== item.id))}><X size={15} /></button>
      </div>)}
    </div>
  </ToastContext.Provider>;
}
export function useToast() {
  const value = useContext(ToastContext);
  if (!value) throw new Error('useToast must be used inside ToastProvider');
  return value;
}
