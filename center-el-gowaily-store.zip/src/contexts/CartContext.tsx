import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { CartDisplayLine, CartLine, Product, ProductVariant } from '../types';
import { getProductsByIds } from '../services/repository';
import { readStorage, writeStorage } from '../utils/storage';
import { effectivePrice, stockFor } from '../utils/format';
import { useToast } from './ToastContext';
import { useLocale } from './LocaleContext';

interface CartContextValue {
  lines: CartDisplayLine[];
  itemCount: number;
  subtotal: number;
  isLoading: boolean;
  drawerOpen: boolean;
  openDrawer: () => void;
  closeDrawer: () => void;
  addItem: (product: Product, variant?: ProductVariant | null, quantity?: number) => void;
  setQuantity: (productId: string, variantId: string | null, quantity: number) => void;
  removeItem: (productId: string, variantId: string | null) => void;
  clearCart: () => void;
}
const CartContext = createContext<CartContextValue | null>(null);
const CART_KEY = 'ceg.cart';
const lineId = (id: string, variantId: string | null) => `${id}::${variantId ?? 'simple'}`;

export function CartProvider({ children }: { children: ReactNode }) {
  const { notify } = useToast();
  const { t } = useLocale();
  const [cart, setCart] = useState<CartLine[]>(() => readStorage<CartLine[]>(CART_KEY, []));
  const [products, setProducts] = useState<Record<string, Product>>({});
  const [isLoading, setIsLoading] = useState(cart.length > 0);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => { writeStorage(CART_KEY, cart); }, [cart]);
  useEffect(() => {
    let current = true;
    const ids = [...new Set(cart.map(item => item.productId))];
    if (!ids.length) { setProducts({}); setIsLoading(false); return; }
    setIsLoading(true);
    getProductsByIds(ids).then(result => {
      if (!current) return;
      setProducts(Object.fromEntries(result.map(product => [product.id, product])));
      setIsLoading(false);
    }).catch(() => { if (current) setIsLoading(false); });
    return () => { current = false; };
  }, [cart]);

  const addItem = useCallback((product: Product, variant: ProductVariant | null = null, quantity = 1) => {
    if (!product.active) { notify(t('unavailable'), 'error'); return; }
    const selected = variant ? product.variants.find(item => item.id === variant.id && item.active) ?? null : null;
    if (product.variants.length && !selected) { notify(t('selectSize'), 'error'); return; }
    const available = stockFor(product, selected);
    if (available <= 0) { notify(t('soldOut'), 'error'); return; }
    const key = lineId(product.id, selected?.id ?? null);
    const existing = cart.find(item => lineId(item.productId, item.variantId) === key);
    const nextQuantity = (existing?.quantity ?? 0) + quantity;
    if (nextQuantity > available) { notify(t('lowStockNotice'), 'error'); return; }
    setProducts(current => ({ ...current, [product.id]: product }));
    setCart(current => {
      const found = current.find(item => lineId(item.productId, item.variantId) === key);
      return found
        ? current.map(item => lineId(item.productId, item.variantId) === key ? { ...item, quantity: item.quantity + quantity } : item)
        : [...current, { productId: product.id, variantId: selected?.id ?? null, quantity }];
    });
    notify(t('addedToBag'));
    setDrawerOpen(true);
  }, [cart, notify, t]);

  const setQuantity = useCallback((productId: string, variantId: string | null, quantity: number) => {
    const product = products[productId];
    if (!product) return;
    if (quantity <= 0) { setCart(current => current.filter(item => lineId(item.productId, item.variantId) !== lineId(productId, variantId))); return; }
    const variant = variantId ? product.variants.find(item => item.id === variantId) ?? null : null;
    const max = stockFor(product, variant);
    if (quantity > max) { notify(t('lowStockNotice'), 'error'); quantity = max; }
    if (quantity <= 0) { removeItem(productId, variantId); return; }
    setCart(current => current.map(item => lineId(item.productId, item.variantId) === lineId(productId, variantId) ? { ...item, quantity } : item));
  }, [products, notify, t]);

  const removeItem = useCallback((productId: string, variantId: string | null) => {
    setCart(current => current.filter(item => lineId(item.productId, item.variantId) !== lineId(productId, variantId)));
  }, []);
  const clearCart = useCallback(() => { setCart([]); setDrawerOpen(false); }, []);

  const lines = useMemo(() => cart.flatMap(item => {
    const product = products[item.productId];
    if (!product) return [];
    const variant = item.variantId ? product.variants.find(value => value.id === item.variantId) ?? null : null;
    const unitPrice = effectivePrice(product, variant);
    return [{ ...item, product, variant, unitPrice, lineTotal: unitPrice * item.quantity, maxQuantity: stockFor(product, variant) }];
  }), [cart, products]);
  const itemCount = cart.reduce((total, item) => total + item.quantity, 0);
  const subtotal = lines.reduce((total, item) => total + item.lineTotal, 0);
  const value = useMemo(() => ({
    lines, itemCount, subtotal, isLoading, drawerOpen,
    openDrawer: () => setDrawerOpen(true), closeDrawer: () => setDrawerOpen(false),
    addItem, setQuantity, removeItem, clearCart,
  }), [lines, itemCount, subtotal, isLoading, drawerOpen, addItem, setQuantity, removeItem, clearCart]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
export function useCart() {
  const value = useContext(CartContext);
  if (!value) throw new Error('useCart must be used inside CartProvider');
  return value;
}
