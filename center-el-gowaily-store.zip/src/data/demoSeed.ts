import type { Category, ColorOption, Product, Promotion, SizeOption, StoreSettings } from '../types';

const color = (key: string, ar: string, en: string, hex: string) => ({ key, name: { ar, en }, hex });
const sizes = (...values: string[]) => values;
const variants = (
  options: Array<{ size?: string; color?: ReturnType<typeof color>; stock: number; sku: string }>,
) => options.map((item, index) => ({ id: `variant-${item.sku.toLowerCase() || index}`, ...item, active: true }));
const now = '2026-10-05T10:00:00.000Z';

export const demoCategories: Category[] = [
  { id: 'cat-men', slug: 'men', name: { ar: 'رجالي', en: 'Men' }, description: { ar: 'أساسيات وإطلالات يومية بتفاصيل مدروسة.', en: 'Everyday essentials with considered details.' }, image: '/images/look-tee.jpg', active: true, sortOrder: 1 },
  { id: 'cat-women', slug: 'women', name: { ar: 'حريمي', en: 'Women' }, description: { ar: 'قطع عملية وأنيقة لكل يوم.', en: 'Practical, considered pieces for every day.' }, image: '/images/look-women.jpg', active: true, sortOrder: 2 },
  { id: 'cat-kids', slug: 'kids', name: { ar: 'أطفال', en: 'Kids' }, description: { ar: 'راحة وحركة وألوان يحبونها.', en: 'Comfort, movement, and colors they love.' }, image: '/images/look-kids.jpg', active: true, sortOrder: 3 },
  { id: 'cat-tops', slug: 'tops', name: { ar: 'تيشيرتات وقمصان', en: 'Tops & shirts' }, description: { ar: 'طبقات أساسية بخامات مريحة.', en: 'Comfortable layers, made for repeat wear.' }, image: '/images/look-tee.jpg', parentId: 'cat-men', active: true, sortOrder: 4 },
  { id: 'cat-bottoms', slug: 'bottoms', name: { ar: 'بناطيل', en: 'Trousers' }, description: { ar: 'قصّات مريحة وتفاصيل عملية.', en: 'Easy fits with thoughtful utility.' }, image: '/images/look-cargo.jpg', active: true, sortOrder: 5 },
  { id: 'cat-accessories', slug: 'accessories', name: { ar: 'إكسسوارات', en: 'Accessories' }, description: { ar: 'اللمسة الأخيرة لإطلالتك.', en: 'The finishing touch to your look.' }, image: '/images/look-women.jpg', active: true, sortOrder: 6 },
];

const navy = color('navy', 'كحلي', 'Navy', '#283448');
const black = color('black', 'أسود', 'Black', '#282927');
const ivory = color('ivory', 'عاجي', 'Ivory', '#e8e1d4');
const olive = color('olive', 'زيتي', 'Olive', '#7a8061');
const rust = color('rust', 'طوبي', 'Rust', '#ba6748');
const sand = color('sand', 'رملي', 'Sand', '#bdab8d');

function product(input: Omit<Product, 'createdAt' | 'updatedAt'>): Product {
  return { ...input, createdAt: now, updatedAt: now };
}

export const demoProducts: Product[] = [
  product({
    id: 'prod-everyday-tee', slug: 'everyday-cotton-tee', name: { ar: 'تيشيرت القطن اليومي', en: 'Everyday cotton tee' },
    description: { ar: 'قطن ناعم بوزن مريح وقصّة واسعة باعتدال. قطعة أساسية سهلة التنسيق من الصباح إلى المساء.', en: 'Soft mid-weight cotton with an easy, relaxed fit. A dependable everyday layer from morning to evening.' },
    categoryId: 'cat-tops', category: { ar: 'تيشيرتات وقمصان', en: 'Tops & shirts' },
    images: [{ id: 'tee-1', url: '/images/look-tee.jpg', alt: { ar: 'تيشيرت قطني كحلي بقصّة مريحة', en: 'Relaxed navy cotton tee' } }],
    price: 790, salePrice: 645, sku: 'EG-M-TEE-01', active: true, featured: true, stock: 0,
    variants: variants(sizes('S', 'M', 'L', 'XL').flatMap((size, i) => [
      { size, color: navy, stock: [8, 12, 9, 4][i], sku: `TEE-NV-${size}` },
      { size, color: ivory, stock: [5, 8, 7, 3][i], sku: `TEE-IV-${size}` },
    ])),
  }),
  product({
    id: 'prod-cargo', slug: 'city-cargo-trouser', name: { ar: 'بنطال سيتي كارغو', en: 'City cargo trouser' },
    description: { ar: 'بنطال كارغو بقصّة مستقيمة وجيوب عملية، بخامة متينة وناعمة تناسب الحركة طوال اليوم.', en: 'A straight-leg cargo trouser with useful pockets and a soft, durable hand feel, made to move through the day.' },
    categoryId: 'cat-bottoms', category: { ar: 'بناطيل', en: 'Trousers' },
    images: [{ id: 'cargo-1', url: '/images/look-cargo.jpg', alt: { ar: 'بنطال كارغو زيتي بقصّة مستقيمة', en: 'Olive straight-leg cargo trousers' } }],
    price: 1390, salePrice: null, sku: 'EG-M-TR-02', active: true, featured: true, stock: 0,
    variants: variants(['30', '32', '34', '36'].flatMap((size, i) => [
      { size, color: olive, stock: [4, 8, 6, 3][i], sku: `CRG-OL-${size}` },
      { size, color: black, stock: [2, 7, 5, 2][i], sku: `CRG-BK-${size}` },
    ])),
  }),
  product({
    id: 'prod-overshirt', slug: 'olive-linen-overshirt', name: { ar: 'قميص لينن أوفرشيرت', en: 'Linen blend overshirt' },
    description: { ar: 'طبقة خفيفة من مزيج الكتان بملمس طبيعي وأزرار هادئة. ارتديه مفتوحًا أو كقميص مستقل.', en: 'A lightweight linen blend with a natural texture and quiet buttons. Wear it open as a layer or on its own.' },
    categoryId: 'cat-women', category: { ar: 'حريمي', en: 'Women' },
    images: [{ id: 'overshirt-1', url: '/images/look-women.jpg', alt: { ar: 'إطلالة قميص زيتي وقطعة عاجية', en: 'Olive overshirt and ivory separates' } }],
    price: 1680, salePrice: 1490, sku: 'EG-W-SH-08', active: true, featured: true, stock: 0,
    variants: variants(sizes('S', 'M', 'L', 'XL').map((size, i) => ({ size, color: olive, stock: [3, 6, 6, 2][i], sku: `OVS-OL-${size}` }))),
  }),
  product({
    id: 'prod-wide-leg', slug: 'wide-leg-everyday-pant', name: { ar: 'بنطال يومي واسع', en: 'Wide-leg everyday pant' },
    description: { ar: 'خصر مريح وقصّة واسعة تنسدل بخفة. قطعة متعددة الاستخدامات بتفاصيل بسيطة.', en: 'A comfortable waist and fluid wide leg make this a versatile everyday piece with a clean finish.' },
    categoryId: 'cat-bottoms', category: { ar: 'بناطيل', en: 'Trousers' },
    images: [{ id: 'wide-1', url: '/images/look-women.jpg', alt: { ar: 'بنطال واسع بلون رملي', en: 'Sand wide-leg trousers' } }],
    price: 1250, salePrice: null, sku: 'EG-W-TR-04', active: true, featured: true, stock: 0,
    variants: variants(sizes('S', 'M', 'L', 'XL').flatMap((size, i) => [
      { size, color: sand, stock: [3, 7, 5, 3][i], sku: `WLP-SA-${size}` },
      { size, color: black, stock: [1, 4, 4, 2][i], sku: `WLP-BK-${size}` },
    ])),
  }),
  product({
    id: 'prod-kids-hoodie', slug: 'weekend-kids-hoodie', name: { ar: 'هودي ويك إند للأطفال', en: 'Weekend kids hoodie' },
    description: { ar: 'هودي قطني بملمس دافئ وبطانة ناعمة، مع مساحة للحركة ومقاس مريح للطبقات.', en: 'A soft, warm cotton hoodie with room to move and an easy fit for layering.' },
    categoryId: 'cat-kids', category: { ar: 'أطفال', en: 'Kids' },
    images: [{ id: 'kids-1', url: '/images/look-kids.jpg', alt: { ar: 'هودي طوبي للأطفال', en: 'Rust hoodie for kids' } }],
    price: 980, salePrice: null, sku: 'EG-K-HD-03', active: true, featured: true, stock: 0,
    variants: variants(sizes('6–8', '8–10', '10–12').map((size, i) => ({ size, color: rust, stock: [5, 7, 4][i], sku: `KHD-RS-${i + 1}` }))),
  }),
  product({
    id: 'prod-shirt', slug: 'classic-poplin-shirt', name: { ar: 'قميص بوبلين كلاسيك', en: 'Classic poplin shirt' },
    description: { ar: 'قميص بوبلين بملمس ناعم وياقة مرتبة. اختيار عملي للعمل والمناسبات البسيطة.', en: 'A smooth poplin shirt with a neat collar, suited to workdays and understated occasions.' },
    categoryId: 'cat-tops', category: { ar: 'تيشيرتات وقمصان', en: 'Tops & shirts' },
    images: [{ id: 'shirt-1', url: '/images/hero-editorial.jpg', alt: { ar: 'قميص يومي بخامة ناعمة', en: 'Soft everyday shirt' } }],
    price: 1190, salePrice: 990, sku: 'EG-M-SH-09', active: true, featured: false, stock: 0,
    variants: variants(sizes('S', 'M', 'L', 'XL').map((size, i) => ({ size, color: ivory, stock: [4, 9, 7, 3][i], sku: `POP-IV-${size}` }))),
  }),
  product({
    id: 'prod-tote', slug: 'everyday-canvas-tote', name: { ar: 'حقيبة كانفاس يومية', en: 'Everyday canvas tote' },
    description: { ar: 'حقيبة كانفاس متينة بمساحة واسعة وحمّالات مريحة. لا تحتاج إلى مقاس أو تنسيق خاص.', en: 'A sturdy canvas carryall with generous room and comfortable straps. No sizing or styling rules required.' },
    categoryId: 'cat-accessories', category: { ar: 'إكسسوارات', en: 'Accessories' },
    images: [{ id: 'tote-1', url: '/images/look-cargo.jpg', alt: { ar: 'إكسسوار يومي بلون محايد', en: 'Neutral everyday accessory' } }],
    price: 420, salePrice: null, sku: 'EG-A-TT-01', active: true, featured: true, stock: 19, variants: [],
  }),
  product({
    id: 'prod-polo', slug: 'cotton-pique-polo', name: { ar: 'تيشيرت بولو بيكيه', en: 'Cotton pique polo' },
    description: { ar: 'قطن بيكيه مريح وياقة ناعمة وأزرار بسيطة. لمسة مرتبة دون مبالغة.', en: 'Comfortable cotton pique, a soft collar, and understated buttons for a neat but relaxed look.' },
    categoryId: 'cat-men', category: { ar: 'رجالي', en: 'Men' },
    images: [{ id: 'polo-1', url: '/images/look-tee.jpg', alt: { ar: 'بولو قطني كحلي', en: 'Navy cotton polo' } }],
    price: 890, salePrice: null, sku: 'EG-M-PL-05', active: true, featured: false, stock: 0,
    variants: variants(sizes('S', 'M', 'L', 'XL').map((size, i) => ({ size, color: navy, stock: [5, 8, 6, 3][i], sku: `POL-NV-${size}` }))),
  }),
  product({
    id: 'prod-jacket', slug: 'utility-light-jacket', name: { ar: 'جاكيت خفيف عملي', en: 'Utility light jacket' },
    description: { ar: 'جاكيت خفيف بجيوب عملية وقصّة سهلة للطبقات. مناسب لأيام الانتقال بين الفصول.', en: 'A lightweight jacket with useful pockets and an easy layering fit for in-between weather.' },
    categoryId: 'cat-men', category: { ar: 'رجالي', en: 'Men' },
    images: [{ id: 'jacket-1', url: '/images/hero-editorial.jpg', alt: { ar: 'جاكيت عملي بلون داكن', en: 'Dark utility jacket' } }],
    price: 2140, salePrice: 1890, sku: 'EG-M-JK-11', active: true, featured: false, stock: 0,
    variants: variants(sizes('M', 'L', 'XL').map((size, i) => ({ size, color: olive, stock: [2, 4, 2][i], sku: `JKT-OL-${size}` }))),
  }),
];

export const demoSizes: SizeOption[] = [
  ...['XS', 'S', 'M', 'L', 'XL', '2XL', '38', '40', '42', '44', '6–8', '8–10', '10–12'].map((label, index) => ({ id: `size-${label}`, label, sortOrder: index, active: true })),
];
export const demoColors: ColorOption[] = [
  { id: 'color-black', key: 'black', name: { ar: 'أسود', en: 'Black' }, hex: '#282927', active: true },
  { id: 'color-navy', key: 'navy', name: { ar: 'كحلي', en: 'Navy' }, hex: '#283448', active: true },
  { id: 'color-ivory', key: 'ivory', name: { ar: 'عاجي', en: 'Ivory' }, hex: '#e8e1d4', active: true },
  { id: 'color-olive', key: 'olive', name: { ar: 'زيتي', en: 'Olive' }, hex: '#7a8061', active: true },
  { id: 'color-rust', key: 'rust', name: { ar: 'طوبي', en: 'Rust' }, hex: '#ba6748', active: true },
  { id: 'color-sand', key: 'sand', name: { ar: 'رملي', en: 'Sand' }, hex: '#bdab8d', active: true },
];
export const demoSettings: StoreSettings = {
  storeName: { ar: 'سنتر الجويلي', en: 'Center El Gowaily' },
  deliveryFee: 60,
  freeDeliveryThreshold: 2000,
  phone: '+20 100 000 0000',
  featuredProductIds: ['prod-everyday-tee', 'prod-cargo', 'prod-overshirt', 'prod-wide-leg', 'prod-kids-hoodie', 'prod-tote'],
};
export const demoPromotions: Promotion[] = [];
