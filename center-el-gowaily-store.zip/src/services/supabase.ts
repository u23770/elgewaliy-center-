import { createClient } from '@supabase/supabase-js';

const env = import.meta.env;
const url = env.VITE_SUPABASE_URL as string | undefined;
const anonKey = env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const isSupabaseConfigured = Boolean(url && anonKey);
export const supabase = isSupabaseConfigured
  ? createClient(url!, anonKey!, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
      global: { headers: { 'x-application-name': 'center-el-gowaily' } },
    })
  : null;

// This adapter is for local UI evaluation only. Production access control is enforced by Supabase RLS.
export const isDemoMode = !supabase || env.VITE_USE_DEMO_DATA === 'true';
