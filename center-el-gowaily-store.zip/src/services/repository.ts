import type {
  AddressInput, Category, CheckoutInput, ColorOption, CustomerProfile, Order, OrderEvent, OrderItem,
  OrderStatus, Product, ProductColor, ProductImage, ProductVariant, Promotion, SizeOption, StoreSettings,
} from '../types';
import { demoCategories, demoColors, demoProducts, demoPromotions, demoSettings, demoSizes } from '../data/demoSeed';
import { readStorage, writeStorage } from '../utils/storage';
import { colorKey, makeSlug } from '../utils/format';
import { isDemoMode, supabase } from './supabase';

const KEYS = {
  products: 'ceg.demo.products', categories: 'ceg.demo.categories', orders: 'ceg.demo.orders', users: 'ceg.demo.users',
  settings: 'ceg.demo.settings', promotions: 'ceg.demo.promotions', sizes: 'ceg.demo.sizes', colors: 'ceg.demo.colors',
};
const defaultSettings: StoreSettings = { ...demoSettings };
const activeProducts = (includeInactive = false) => readStorage<Product[]>(KEYS.products, demoProducts).filter(p => includeInactive || p.active);
const allCategories = () => readStorage<Category[]>(KEYS.categories, demoCategories);
const allOrders = () => readStorage<Order[]>(KEYS.orders, []);
const uid = () => globalThis.crypto?.randomUUID?.() ?? `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

export interface ProductQuery {
  query?: string;
  categorySlug?: string;
  sort?: 'featured' | 'newest' | 'price-asc' | 'price-desc';
  includeInactive?: boolean;
}

function localizedFromRow(row: Record<string, unknown>, prefix: string): { ar: string; en: string } {
  return { ar: String(row[`${prefix}_ar`] ?? ''), en: String(row[`${prefix}_en`] ?? '') };
}
function mapCategory(row: any): Category {
  return {
    id: row.id, slug: row.slug, name: localizedFromRow(row, 'name'), description: localizedFromRow(row, 'description'),
    image: row.image_url ?? row.image ?? undefined, parentId: row.parent_id ?? null, active: row.is_active ?? true,
    sortOrder: Number(row.sort_order ?? 0),
  };
}
function mapProduct(row: any): Product {
  const variants: ProductVariant[] = (row.product_variants ?? []).map((variant: any) => {
    const inventory = Array.isArray(variant.inventory) ? variant.inventory[0] : variant.inventory;
    const color: ProductColor | undefined = variant.color_name_en || variant.color_name_ar ? {
      key: variant.color_key || colorKey(variant.color_name_en || variant.color_name_ar),
      name: { en: variant.color_name_en ?? '', ar: variant.color_name_ar ?? '' }, hex: variant.color_hex ?? '#d6d0c4',
    } : undefined;
    return {
      id: variant.id, sku: variant.sku ?? undefined, size: variant.size_label ?? undefined, color,
      stock: Number(inventory?.quantity ?? variant.stock_quantity ?? 0),
      priceOverride: variant.price_override === null ? null : Number(variant.price_override), imageUrl: variant.image_url ?? undefined,
      active: variant.is_active ?? true,
    };
  });
  const images: ProductImage[] = (row.product_images ?? []).map((image: any) => ({
    id: image.id, url: image.image_url, alt: { en: image.alt_en ?? row.name_en ?? '', ar: image.alt_ar ?? row.name_ar ?? '' },
    colorKey: image.color_key ?? undefined,
  }));
  const category = Array.isArray(row.categories) ? row.categories[0] : row.categories;
  return {
    id: row.id, slug: row.slug, name: localizedFromRow(row, 'name'), description: localizedFromRow(row, 'description'),
    categoryId: row.category_id ?? '',
    category: category ? localizedFromRow(category, 'name') : undefined,
    images, price: Number(row.price ?? 0), salePrice: row.sale_price === null || row.sale_price === undefined ? null : Number(row.sale_price),
    sku: row.sku ?? '', active: row.is_active ?? false, featured: row.is_featured ?? false, stock: Number(row.stock_quantity ?? 0),
    variants, createdAt: row.created_at ?? new Date().toISOString(), updatedAt: row.updated_at ?? new Date().toISOString(),
  };
}
function mapOrderItem(row: any): OrderItem {
  const snapshot = row.product_snapshot ?? row.snapshot ?? {};
  const color = snapshot.color_name_en || snapshot.color_name_ar ? {
    key: snapshot.color_key || colorKey(snapshot.color_name_en || snapshot.color_name_ar),
    name: { en: snapshot.color_name_en ?? '', ar: snapshot.color_name_ar ?? '' }, hex: snapshot.color_hex ?? '#d6d0c4',
  } : undefined;
  return {
    id: row.id ?? uid(), productId: row.product_id ?? '', variantId: row.variant_id ?? null,
    productName: snapshot.name ?? { en: snapshot.name_en ?? row.product_name_en ?? '', ar: snapshot.name_ar ?? row.product_name_ar ?? '' },
    image: snapshot.image_url ?? row.image_url ?? undefined, sku: snapshot.sku ?? row.sku ?? undefined,
    size: snapshot.size_label ?? row.size_label ?? undefined, color, quantity: Number(row.quantity ?? 0),
    unitPrice: Number(row.unit_price ?? row.price ?? 0), total: Number(row.line_total ?? row.total ?? 0),
  };
}
function mapOrder(row: any): Order {
  const address = (row.delivery_address ?? row.address ?? {}) as AddressInput;
  const rawEvents = row.order_events ?? row.events ?? [];
  const items = row.order_items ?? row.items ?? [];
  return {
    id: row.id, orderNumber: row.order_number, userId: row.user_id ?? null, customerName: row.customer_name ?? '',
    customerEmail: row.customer_email ?? '', phone: row.customer_phone ?? row.phone ?? '', address,
    paymentMethod: row.payment_method, status: row.status as OrderStatus,
    items: items.map(mapOrderItem), subtotal: Number(row.subtotal ?? 0), deliveryFee: Number(row.delivery_fee ?? 0),
    total: Number(row.total ?? 0), events: rawEvents.map((event: any): OrderEvent => ({ status: event.status, at: event.created_at ?? event.at, note: event.note ?? undefined })),
    createdAt: row.created_at ?? new Date().toISOString(), updatedAt: row.updated_at ?? new Date().toISOString(),
  };
}

function attachDemoCategory(product: Product, categories = allCategories()): Product {
  return { ...product, category: categories.find(c => c.id === product.categoryId)?.name ?? product.category };
}
function normalizedSearch(product: Product, query: string): boolean {
  const value = query.trim().toLocaleLowerCase();
  if (!value) return true;
  return [product.name.en, product.name.ar, product.description.en, product.description.ar, product.sku, product.category?.en, product.category?.ar]
    .some(item => item?.toLocaleLowerCase().includes(value));
}
function orderSort(products: Product[], sort: ProductQuery['sort']): Product[] {
  const copy = [...products];
  if (sort === 'price-asc') return copy.sort((a, b) => (a.salePrice ?? a.price) - (b.salePrice ?? b.price));
  if (sort === 'price-desc') return copy.sort((a, b) => (b.salePrice ?? b.price) - (a.salePrice ?? a.price));
  if (sort === 'newest') return copy.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return copy.sort((a, b) => Number(b.featured) - Number(a.featured));
}

export async function listProducts(query: ProductQuery = {}): Promise<Product[]> {
  let products: Product[];
  if (isDemoMode) {
    products = activeProducts(Boolean(query.includeInactive)).map(p => attachDemoCategory(p));
  } else {
    const result = await supabase!.from('products')
      .select('*, categories(id,name_en,name_ar,slug), product_images(*), product_variants(*, inventory(quantity))')
      .order('created_at', { ascending: false });
    if (result.error) throw result.error;
    products = (result.data ?? []).map(mapProduct).filter(p => query.includeInactive || p.active);
  }
  if (query.categorySlug) {
    const cats = await listCategories(true);
    const ids = new Set(cats.filter(c => c.slug === query.categorySlug || c.id === query.categorySlug).map(c => c.id));
    products = products.filter(p => ids.has(p.categoryId));
  }
  if (query.query) products = products.filter(p => normalizedSearch(p, query.query!));
  return orderSort(products, query.sort ?? 'featured');
}

export async function getProductBySlug(slug: string, includeInactive = false): Promise<Product | null> {
  if (isDemoMode) return activeProducts(includeInactive).map(p => attachDemoCategory(p)).find(p => p.slug === slug || p.id === slug) ?? null;
  let request = supabase!.from('products').select('*, categories(id,name_en,name_ar,slug), product_images(*), product_variants(*, inventory(quantity))').eq('slug', slug);
  if (!includeInactive) request = request.eq('is_active', true);
  const { data, error } = await request.maybeSingle();
  if (error) throw error;
  return data ? mapProduct(data) : null;
}

export async function getProductsByIds(ids: string[]): Promise<Product[]> {
  if (!ids.length) return [];
  if (isDemoMode) return activeProducts(true).filter(p => ids.includes(p.id)).map(p => attachDemoCategory(p));
  const { data, error } = await supabase!.from('products')
    .select('*, categories(id,name_en,name_ar,slug), product_images(*), product_variants(*, inventory(quantity))').in('id', ids);
  if (error) throw error;
  return (data ?? []).map(mapProduct);
}

export async function listCategories(includeInactive = false): Promise<Category[]> {
  if (isDemoMode) return allCategories().filter(c => includeInactive || c.active).sort((a, b) => a.sortOrder - b.sortOrder);
  let request = supabase!.from('categories').select('*').order('sort_order');
  if (!includeInactive) request = request.eq('is_active', true);
  const { data, error } = await request;
  if (error) throw error;
  return (data ?? []).map(mapCategory);
}

export async function saveCategory(input: Partial<Category> & { name: { ar: string; en: string }; slug: string }): Promise<Category> {
  const category: Category = {
    id: input.id ?? uid(), slug: input.slug || makeSlug(input.name.en), name: input.name,
    description: input.description, image: input.image, parentId: input.parentId ?? null,
    active: input.active ?? true, sortOrder: input.sortOrder ?? 0,
  };
  if (isDemoMode) {
    const list = allCategories();
    writeStorage(KEYS.categories, list.some(c => c.id === category.id) ? list.map(c => c.id === category.id ? category : c) : [...list, category]);
    return category;
  }
  const { data, error } = await supabase!.from('categories').upsert({
    id: input.id || undefined, slug: category.slug, name_en: category.name.en, name_ar: category.name.ar,
    description_en: category.description?.en ?? '', description_ar: category.description?.ar ?? '',
    image_url: category.image ?? null, parent_id: category.parentId, is_active: category.active, sort_order: category.sortOrder,
  }).select('*').single();
  if (error) throw error;
  return mapCategory(data);
}

export async function deleteCategory(id: string): Promise<void> {
  if (isDemoMode) {
    writeStorage(KEYS.categories, allCategories().map(c => c.id === id ? { ...c, active: false } : c));
    return;
  }
  const { error } = await supabase!.from('categories').update({ is_active: false }).eq('id', id);
  if (error) throw error;
}

export async function saveProduct(input: Product): Promise<Product> {
  const product: Product = { ...input, id: input.id || uid(), slug: input.slug || makeSlug(input.name.en || input.name.ar), updatedAt: new Date().toISOString() };
  if (isDemoMode) {
    const list = readStorage<Product[]>(KEYS.products, demoProducts);
    writeStorage(KEYS.products, list.some(p => p.id === product.id) ? list.map(p => p.id === product.id ? product : p) : [{ ...product, createdAt: product.createdAt || new Date().toISOString() }, ...list]);
    return attachDemoCategory(product);
  }
  const pProduct = {
    id: input.id || null, slug: product.slug, name_en: product.name.en, name_ar: product.name.ar,
    description_en: product.description.en, description_ar: product.description.ar, category_id: product.categoryId || null,
    price: product.price, sale_price: product.salePrice ?? null, sku: product.sku, is_active: product.active,
    is_featured: product.featured, stock_quantity: product.stock,
  };
  const pImages = product.images.map(image => ({ image_url: image.url, alt_en: image.alt.en, alt_ar: image.alt.ar, color_key: image.colorKey ?? null }));
  const pVariants = product.variants.map(variant => ({
    sku: variant.sku ?? null, size_label: variant.size ?? null,
    color_key: variant.color?.key ?? null, color_name_en: variant.color?.name.en ?? null,
    color_name_ar: variant.color?.name.ar ?? null, color_hex: variant.color?.hex ?? null,
    stock_quantity: variant.stock, price_override: variant.priceOverride ?? null, image_url: variant.imageUrl ?? null, is_active: variant.active,
  }));
  const { data, error } = await supabase!.rpc('admin_save_product', { p_product: pProduct, p_images: pImages, p_variants: pVariants });
  if (error) throw error;
  const savedId = String(data);
  const { data: row, error: fetchError } = await supabase!.from('products')
    .select('*, categories(id,name_en,name_ar,slug), product_images(*), product_variants(*, inventory(quantity))').eq('id', savedId).single();
  if (fetchError) throw fetchError;
  return mapProduct(row);
}

export async function deactivateProduct(id: string): Promise<void> {
  if (isDemoMode) {
    writeStorage(KEYS.products, readStorage<Product[]>(KEYS.products, demoProducts).map(p => p.id === id ? { ...p, active: false } : p));
    return;
  }
  const { error } = await supabase!.from('products').update({ is_active: false }).eq('id', id);
  if (error) throw error;
}

export async function uploadProductImage(file: File): Promise<string> {
  if (isDemoMode) {
    return await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error('Image could not be read.'));
      reader.readAsDataURL(file);
    });
  }
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-');
  const path = `${Date.now()}-${safeName}`;
  const { error } = await supabase!.storage.from('product-images').upload(path, file, { upsert: false, cacheControl: '3600' });
  if (error) throw error;
  return supabase!.storage.from('product-images').getPublicUrl(path).data.publicUrl;
}

export async function createOrder(input: CheckoutInput): Promise<Order> {
  if (!input.items.length) throw new Error('Your bag is empty.');
  if (!/^\+?\d[\d\s()-]{7,16}$/.test(input.phone.trim())) throw new Error('Invalid phone number.');
  if (isDemoMode) {
    const products = readStorage<Product[]>(KEYS.products, demoProducts);
    const orderItems: OrderItem[] = [];
    let subtotal = 0;
    for (const line of input.items) {
      const product = products.find(p => p.id === line.productId && p.active);
      if (!product) throw new Error('One of the products is no longer available.');
      const variant = line.variantId ? product.variants.find(v => v.id === line.variantId && v.active) : null;
      if (product.variants.length && !variant) throw new Error('Please select an available variant.');
      const stock = variant ? variant.stock : product.stock;
      if (line.quantity < 1 || line.quantity > stock) throw new Error('The selected quantity is no longer available.');
      const unitPrice = variant?.priceOverride ?? product.salePrice ?? product.price;
      const total = unitPrice * line.quantity;
      subtotal += total;
      orderItems.push({
        id: uid(), productId: product.id, variantId: variant?.id ?? null, productName: product.name,
        image: variant?.imageUrl ?? product.images.find(img => img.colorKey === variant?.color?.key)?.url ?? product.images[0]?.url,
        sku: variant?.sku ?? product.sku, size: variant?.size, color: variant?.color,
        quantity: line.quantity, unitPrice, total,
      });
    }
    const settings = readStorage<StoreSettings>(KEYS.settings, defaultSettings);
    const deliveryFee = subtotal >= settings.freeDeliveryThreshold ? 0 : settings.deliveryFee;
    const now = new Date().toISOString();
    const orderNumber = `EG-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    const order: Order = {
      id: uid(), orderNumber, userId: input.userId ?? null, customerName: input.customerName.trim(), customerEmail: input.email?.trim() ?? '',
      phone: input.phone.trim(), address: input.address, paymentMethod: input.paymentMethod, status: 'pending', items: orderItems,
      subtotal, deliveryFee, total: subtotal + deliveryFee, events: [{ status: 'pending', at: now }], createdAt: now, updatedAt: now,
    };
    for (const line of input.items) {
      const product = products.find(p => p.id === line.productId)!;
      if (line.variantId) product.variants = product.variants.map(v => v.id === line.variantId ? { ...v, stock: v.stock - line.quantity } : v);
      else product.stock -= line.quantity;
    }
    writeStorage(KEYS.products, products);
    writeStorage(KEYS.orders, [order, ...allOrders()]);
    return order;
  }
  const payload = {
    customer_name: input.customerName.trim(), customer_email: input.email?.trim() ?? null, customer_phone: input.phone.trim(),
    governorate: input.address.governorate, area: input.address.area, delivery_address: input.address.address,
    notes: input.address.notes ?? null, payment_method: input.paymentMethod, user_id: input.userId ?? null,
    items: input.items.map(({ productId, variantId, quantity }) => ({ product_id: productId, variant_id: variantId, quantity })),
  };
  const { data, error } = await supabase!.rpc('place_order', { p_order: payload });
  if (error) throw error;
  return mapOrder(data);
}

export async function listOrders(user?: CustomerProfile | null): Promise<Order[]> {
  if (isDemoMode) {
    return allOrders().filter(order => !user || user.role === 'admin' || order.userId === user.id || (order.customerEmail ?? '').toLowerCase() === user.email.toLowerCase());
  }
  let request = supabase!.from('orders').select('*, order_items(*), order_events(*)').order('created_at', { ascending: false });
  if (user && user.role !== 'admin') request = request.eq('user_id', user.id);
  const { data, error } = await request;
  if (error) throw error;
  return (data ?? []).map(mapOrder);
}

export async function getOrderById(id: string): Promise<Order | null> {
  if (isDemoMode) return allOrders().find(o => o.id === id || o.orderNumber === id) ?? null;
  const { data, error } = await supabase!.from('orders').select('*, order_items(*), order_events(*)').eq('id', id).maybeSingle();
  if (error) throw error;
  return data ? mapOrder(data) : null;
}

export async function trackOrder(orderNumber: string, phone: string): Promise<Order | null> {
  if (isDemoMode) {
    const normalized = phone.replace(/\D/g, '').slice(-10);
    const order = allOrders().find(o => o.orderNumber.toLowerCase() === orderNumber.toLowerCase());
    return order && order.phone.replace(/\D/g, '').slice(-10) === normalized ? order : null;
  }
  const { data, error } = await supabase!.rpc('track_order', { p_order_number: orderNumber, p_phone: phone.trim() });
  if (error) throw error;
  return data ? mapOrder(data) : null;
}

export async function updateOrderStatus(id: string, status: OrderStatus): Promise<void> {
  if (isDemoMode) {
    const orders = allOrders();
    writeStorage(KEYS.orders, orders.map(o => o.id === id ? {
      ...o, status, updatedAt: new Date().toISOString(), events: [...o.events, { status, at: new Date().toISOString() }],
    } : o));
    return;
  }
  const { error } = await supabase!.from('orders').update({ status }).eq('id', id);
  if (error) throw error;
}

export async function updateStock(productId: string, variantId: string | null, quantity: number): Promise<void> {
  if (!Number.isInteger(quantity) || quantity < 0) throw new Error('Stock must be a non-negative whole number.');
  if (isDemoMode) {
    const products = readStorage<Product[]>(KEYS.products, demoProducts);
    writeStorage(KEYS.products, products.map(p => p.id !== productId ? p : variantId
      ? { ...p, variants: p.variants.map(v => v.id === variantId ? { ...v, stock: quantity } : v) }
      : { ...p, stock: quantity }));
    return;
  }
  if (variantId) {
    const { error } = await supabase!.from('inventory').upsert({ product_variant_id: variantId, quantity, updated_at: new Date().toISOString() }, { onConflict: 'product_variant_id' });
    if (error) throw error;
  } else {
    const { error } = await supabase!.from('products').update({ stock_quantity: quantity }).eq('id', productId);
    if (error) throw error;
  }
}

export async function listCustomers(): Promise<CustomerProfile[]> {
  if (isDemoMode) {
    const users = readStorage<Array<{ id: string; email: string; fullName: string; phone?: string; role: 'customer' | 'admin'; createdAt?: string }>>(KEYS.users, []);
    return users.map(({ id, email, fullName, phone, role, createdAt }) => ({ id, email, fullName, phone, role, createdAt }));
  }
  const { data, error } = await supabase!.from('profiles').select('id,email,full_name,phone,role,created_at').order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map(row => ({ id: row.id, email: row.email ?? '', fullName: row.full_name ?? '', phone: row.phone ?? '', role: row.role, createdAt: row.created_at }));
}

export async function getStoreSettings(): Promise<StoreSettings> {
  if (isDemoMode) return readStorage(KEYS.settings, defaultSettings);
  const { data, error } = await supabase!.from('store_settings').select('value').eq('key', 'general').maybeSingle();
  if (error) throw error;
  return { ...defaultSettings, ...(data?.value as Partial<StoreSettings> ?? {}) };
}

export async function saveStoreSettings(settings: StoreSettings): Promise<void> {
  if (isDemoMode) { writeStorage(KEYS.settings, { ...settings, updatedAt: new Date().toISOString() }); return; }
  const { error } = await supabase!.from('store_settings').upsert({ key: 'general', value: settings, updated_at: new Date().toISOString() });
  if (error) throw error;
}

export async function listPromotions(): Promise<Promotion[]> {
  if (isDemoMode) return readStorage(KEYS.promotions, demoPromotions);
  const { data, error } = await supabase!.from('promotions').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    id: row.id, code: row.code, title: { en: row.title_en, ar: row.title_ar }, discountType: row.discount_type,
    discountValue: Number(row.discount_value), active: row.is_active, startsAt: row.starts_at, endsAt: row.ends_at,
  }));
}

export async function savePromotion(input: Omit<Promotion, 'id'> & { id?: string }): Promise<Promotion> {
  const promotion: Promotion = { ...input, id: input.id ?? uid(), code: input.code.trim().toUpperCase() };
  if (isDemoMode) {
    const list = readStorage<Promotion[]>(KEYS.promotions, demoPromotions);
    writeStorage(KEYS.promotions, list.some(p => p.id === promotion.id) ? list.map(p => p.id === promotion.id ? promotion : p) : [promotion, ...list]);
    return promotion;
  }
  const { data, error } = await supabase!.from('promotions').upsert({
    id: input.id || undefined, code: promotion.code, title_en: promotion.title.en, title_ar: promotion.title.ar,
    discount_type: promotion.discountType, discount_value: promotion.discountValue, is_active: promotion.active,
    starts_at: promotion.startsAt ?? null, ends_at: promotion.endsAt ?? null,
  }).select('*').single();
  if (error) throw error;
  return { id: data.id, code: data.code, title: { en: data.title_en, ar: data.title_ar }, discountType: data.discount_type, discountValue: Number(data.discount_value), active: data.is_active, startsAt: data.starts_at, endsAt: data.ends_at };
}

export async function deletePromotion(id: string): Promise<void> {
  if (isDemoMode) { writeStorage(KEYS.promotions, readStorage<Promotion[]>(KEYS.promotions, demoPromotions).filter(p => p.id !== id)); return; }
  const { error } = await supabase!.from('promotions').delete().eq('id', id);
  if (error) throw error;
}

export async function listSizes(): Promise<SizeOption[]> {
  if (isDemoMode) return readStorage(KEYS.sizes, demoSizes).filter(size => size.active).sort((a, b) => a.sortOrder - b.sortOrder);
  const { data, error } = await supabase!.from('sizes').select('*').order('sort_order');
  if (error) throw error;
  return (data ?? []).map((row: any) => ({ id: row.id, label: row.label, sortOrder: row.sort_order, active: row.is_active }));
}
export async function saveSize(input: Omit<SizeOption, 'id'> & { id?: string }): Promise<void> {
  if (isDemoMode) {
    const list = readStorage<SizeOption[]>(KEYS.sizes, demoSizes); const next = { ...input, id: input.id ?? uid() };
    writeStorage(KEYS.sizes, list.some(v => v.id === next.id) ? list.map(v => v.id === next.id ? next : v) : [...list, next]); return;
  }
  const { error } = await supabase!.from('sizes').upsert({ id: input.id || undefined, label: input.label, sort_order: input.sortOrder, is_active: input.active }).select();
  if (error) throw error;
}
export async function deleteSize(id: string): Promise<void> {
  if (isDemoMode) { writeStorage(KEYS.sizes, readStorage<SizeOption[]>(KEYS.sizes, demoSizes).map(v => v.id === id ? { ...v, active: false } : v)); return; }
  const { error } = await supabase!.from('sizes').update({ is_active: false }).eq('id', id); if (error) throw error;
}
export async function listColors(): Promise<ColorOption[]> {
  if (isDemoMode) return readStorage(KEYS.colors, demoColors).filter(color => color.active);
  const { data, error } = await supabase!.from('colors').select('*').order('name_en');
  if (error) throw error;
  return (data ?? []).map((row: any) => ({ id: row.id, key: row.color_key, name: { en: row.name_en, ar: row.name_ar }, hex: row.hex, active: row.is_active }));
}
export async function saveColor(input: Omit<ColorOption, 'id'> & { id?: string }): Promise<void> {
  if (isDemoMode) {
    const list = readStorage<ColorOption[]>(KEYS.colors, demoColors); const next = { ...input, id: input.id ?? uid() };
    writeStorage(KEYS.colors, list.some(v => v.id === next.id) ? list.map(v => v.id === next.id ? next : v) : [...list, next]); return;
  }
  const { error } = await supabase!.from('colors').upsert({ id: input.id || undefined, color_key: input.key, name_en: input.name.en, name_ar: input.name.ar, hex: input.hex, is_active: input.active });
  if (error) throw error;
}
export async function deleteColor(id: string): Promise<void> {
  if (isDemoMode) { writeStorage(KEYS.colors, readStorage<ColorOption[]>(KEYS.colors, demoColors).map(v => v.id === id ? { ...v, active: false } : v)); return; }
  const { error } = await supabase!.from('colors').update({ is_active: false }).eq('id', id); if (error) throw error;
}

export interface DemoUserRecord extends CustomerProfile { passwordHash: string }
export function getDemoUsers(): DemoUserRecord[] { return readStorage<DemoUserRecord[]>(KEYS.users, []); }
export function saveDemoUsers(users: DemoUserRecord[]): void { writeStorage(KEYS.users, users); }

export function getDeliveryEstimate(subtotal: number, settings: StoreSettings): number {
  return subtotal >= settings.freeDeliveryThreshold ? 0 : settings.deliveryFee;
}
