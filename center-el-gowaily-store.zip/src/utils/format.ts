import type { OrderStatus, PaymentMethod, Product, ProductVariant, Locale } from '../types';

export function effectivePrice(product: Product, variant?: ProductVariant | null): number {
  return variant?.priceOverride ?? product.salePrice ?? product.price;
}

export function discountPercent(price: number, salePrice?: number | null): number | null {
  if (!salePrice || salePrice >= price) return null;
  return Math.round((1 - salePrice / price) * 100);
}

export function stockFor(product: Product, variant?: ProductVariant | null): number {
  return variant ? variant.stock : product.stock;
}

export function statusLabel(status: OrderStatus, locale: Locale): string {
  const values: Record<OrderStatus, { ar: string; en: string }> = {
    pending: { ar: 'قيد المراجعة', en: 'Pending' },
    confirmed: { ar: 'تم التأكيد', en: 'Confirmed' },
    preparing: { ar: 'جارٍ التجهيز', en: 'Preparing' },
    out_for_delivery: { ar: 'خرج للتوصيل', en: 'Out for delivery' },
    delivered: { ar: 'تم التسليم', en: 'Delivered' },
    cancelled: { ar: 'ملغي', en: 'Cancelled' },
  };
  return values[status][locale];
}

export function paymentLabel(method: PaymentMethod, locale: Locale): string {
  return method === 'cash_on_delivery'
    ? (locale === 'ar' ? 'الدفع نقدًا عند الاستلام' : 'Cash on delivery')
    : (locale === 'ar' ? 'بطاقة عند الاستلام' : 'Card on delivery');
}

export function formatDate(date: string, locale: Locale): string {
  return new Intl.DateTimeFormat(locale === 'ar' ? 'ar-EG' : 'en-EG', {
    dateStyle: 'medium', timeStyle: 'short',
  }).format(new Date(date));
}

export function colorKey(value: string): string {
  return value.trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g, '-');
}

export function makeSlug(value: string): string {
  return value.trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g, '-').replace(/^-|-$/g, '');
}
