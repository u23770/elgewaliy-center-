import { useCallback, useEffect, useState } from 'react';

export function useAsyncData<T>(loader: () => Promise<T>, dependencies: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [version, setVersion] = useState(0);
  const retry = useCallback(() => setVersion(value => value + 1), []);
  useEffect(() => {
    let alive = true;
    setLoading(true); setError(null);
    loader().then(value => { if (alive) setData(value); }).catch(reason => { if (alive) setError(reason); }).finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
    // Explicit dependency array is supplied by each page to control reloads.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...dependencies, version]);
  return { data, error, loading, retry, setData };
}
