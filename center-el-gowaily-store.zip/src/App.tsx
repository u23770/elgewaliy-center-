import { lazy, Suspense, type ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { CustomerShell } from './components/layout/CustomerShell';
import { useAuth } from './contexts/AuthContext';
import { useLocale } from './contexts/LocaleContext';
import { Spinner } from './components/ui/primitives';

const AdminShell = lazy(() => import('./components/layout/AdminShell').then(module => ({ default: module.AdminShell })));
const HomePage = lazy(() => import('./pages/customer/HomePage').then(module => ({ default: module.HomePage })));
const ShopPage = lazy(() => import('./pages/customer/ShopPage').then(module => ({ default: module.ShopPage })));
const ProductPage = lazy(() => import('./pages/customer/ProductPage').then(module => ({ default: module.ProductPage })));
const CartPage = lazy(() => import('./pages/customer/CartPage').then(module => ({ default: module.CartPage })));
const CheckoutPage = lazy(() => import('./pages/customer/CheckoutPage').then(module => ({ default: module.CheckoutPage })));
const AccountPage = lazy(() => import('./pages/customer/AccountPage').then(module => ({ default: module.AccountPage })));
const LoginPage = lazy(() => import('./pages/customer/AuthPages').then(module => ({ default: module.LoginPage })));
const RegisterPage = lazy(() => import('./pages/customer/AuthPages').then(module => ({ default: module.RegisterPage })));
const ForgotPasswordPage = lazy(() => import('./pages/customer/AuthPages').then(module => ({ default: module.ForgotPasswordPage })));
const ResetPasswordPage = lazy(() => import('./pages/customer/AuthPages').then(module => ({ default: module.ResetPasswordPage })));
const VerificationPage = lazy(() => import('./pages/customer/AuthPages').then(module => ({ default: module.VerificationPage })));
const OrderDetailPage = lazy(() => import('./pages/customer/OrdersPages').then(module => ({ default: module.OrderDetailPage })));
const OrderHistoryPage = lazy(() => import('./pages/customer/OrdersPages').then(module => ({ default: module.OrderHistoryPage })));
const OrderSuccessPage = lazy(() => import('./pages/customer/OrdersPages').then(module => ({ default: module.OrderSuccessPage })));
const OrderTrackingPage = lazy(() => import('./pages/customer/OrdersPages').then(module => ({ default: module.OrderTrackingPage })));
const AboutPage = lazy(() => import('./pages/customer/InfoPages').then(module => ({ default: module.AboutPage })));
const HelpPage = lazy(() => import('./pages/customer/InfoPages').then(module => ({ default: module.HelpPage })));
const NotFoundPage = lazy(() => import('./pages/customer/InfoPages').then(module => ({ default: module.NotFoundPage })));
const adminPages = import('./pages/admin/AdminPages');
const AdminDashboardPage = lazy(() => adminPages.then(module => ({ default: module.AdminDashboardPage })));
const AdminProductsPage = lazy(() => adminPages.then(module => ({ default: module.AdminProductsPage })));
const AdminCategoriesPage = lazy(() => adminPages.then(module => ({ default: module.AdminCategoriesPage })));
const AdminInventoryPage = lazy(() => adminPages.then(module => ({ default: module.AdminInventoryPage })));
const AdminAttributesPage = lazy(() => adminPages.then(module => ({ default: module.AdminAttributesPage })));
const AdminOrdersPage = lazy(() => adminPages.then(module => ({ default: module.AdminOrdersPage })));
const AdminCustomersPage = lazy(() => adminPages.then(module => ({ default: module.AdminCustomersPage })));
const AdminSettingsPage = lazy(() => adminPages.then(module => ({ default: module.AdminSettingsPage })));
const AdminProductFormPage = lazy(() => import('./pages/admin/AdminProductPages').then(module => ({ default: module.AdminProductFormPage })));

function RequireRole({ children, role }: { children: ReactNode; role: 'customer' | 'admin' }) {
  const { user, isLoading } = useAuth(); const location = useLocation(); const { t } = useLocale();
  if (isLoading) return <div className="route-loading"><Spinner label={t('loading')} /></div>;
  if (!user) return <Navigate to={role === 'admin' ? '/admin/login' : '/login'} state={{ from: location.pathname }} replace />;
  if (role === 'admin' && user.role !== 'admin') return <Navigate to="/admin/login" replace />;
  return <>{children}</>;
}
function AdminRoute() { return <RequireRole role="admin"><AdminShell /></RequireRole>; }
function CustomerRoute({ children }: { children: ReactNode }) { return <RequireRole role="customer">{children}</RequireRole>; }

export function App() {
  const { t } = useLocale();
  return <Suspense fallback={<div className="route-loading"><Spinner label={t('loading')} /></div>}><Routes>
    <Route element={<CustomerShell />}>
      <Route path="/" element={<HomePage />} />
      <Route path="/shop" element={<ShopPage />} />
      <Route path="/search" element={<ShopPage />} />
      <Route path="/category/:slug" element={<ShopPage />} />
      <Route path="/product/:slug" element={<ProductPage />} />
      <Route path="/cart" element={<CartPage />} />
      <Route path="/checkout" element={<CheckoutPage />} />
      <Route path="/order-success/:orderNumber" element={<OrderSuccessPage />} />
      <Route path="/track" element={<OrderTrackingPage />} />
      <Route path="/track/:orderNumber" element={<OrderTrackingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/password/reset" element={<ResetPasswordPage />} />
      <Route path="/auth/verify" element={<VerificationPage />} />
      <Route path="/account" element={<CustomerRoute><AccountPage /></CustomerRoute>} />
      <Route path="/orders" element={<CustomerRoute><OrderHistoryPage /></CustomerRoute>} />
      <Route path="/orders/:id" element={<CustomerRoute><OrderDetailPage /></CustomerRoute>} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/help" element={<HelpPage />} />
      <Route path="*" element={<NotFoundPage />} />
    </Route>
    <Route path="/admin/login" element={<LoginPage adminMode />} />
    <Route path="/admin" element={<AdminRoute />}>
      <Route index element={<AdminDashboardPage />} />
      <Route path="products" element={<AdminProductsPage />} />
      <Route path="products/new" element={<AdminProductFormPage />} />
      <Route path="products/:id/edit" element={<AdminProductFormPage />} />
      <Route path="categories" element={<AdminCategoriesPage />} />
      <Route path="inventory" element={<AdminInventoryPage />} />
      <Route path="attributes" element={<AdminAttributesPage />} />
      <Route path="orders" element={<AdminOrdersPage />} />
      <Route path="customers" element={<AdminCustomersPage />} />
      <Route path="settings" element={<AdminSettingsPage />} />
    </Route>
    <Route path="*" element={<Navigate to="/404" replace />} />
  </Routes></Suspense>;
}
