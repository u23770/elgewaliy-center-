export type Locale = 'ar' | 'en';
export type LocalizedText = { ar: string; en: string };
export type UserRole = 'customer' | 'admin';

export interface ProductImage {
  id: string;
  url: string;
  alt: LocalizedText;
  colorKey?: string;
}

export interface ProductColor {
  key: string;
  name: LocalizedText;
  hex: string;
}

export interface ProductVariant {
  id: string;
  sku?: string;
  size?: string;
  color?: ProductColor;
  stock: number;
  priceOverride?: number | null;
  imageUrl?: string;
  active: boolean;
}

export interface Category {
  id: string;
  slug: string;
  name: LocalizedText;
  description?: LocalizedText;
  image?: string;
  parentId?: string | null;
  active: boolean;
  sortOrder: number;
}

export interface Product {
  id: string;
  slug: string;
  name: LocalizedText;
  description: LocalizedText;
  categoryId: string;
  category?: LocalizedText;
  images: ProductImage[];
  price: number;
  salePrice?: number | null;
  sku: string;
  active: boolean;
  featured: boolean;
  stock: number;
  variants: ProductVariant[];
  createdAt: string;
  updatedAt: string;
}

export interface CartLine {
  productId: string;
  variantId: string | null;
  quantity: number;
}

export interface CartDisplayLine extends CartLine {
  product: Product;
  variant: ProductVariant | null;
  unitPrice: number;
  lineTotal: number;
  maxQuantity: number;
}

export type PaymentMethod = 'cash_on_delivery' | 'card_on_delivery';
export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'out_for_delivery' | 'delivered' | 'cancelled';

export interface CustomerProfile {
  id: string;
  email: string;
  fullName: string;
  phone?: string;
  role: UserRole;
  createdAt?: string;
}

export interface AddressInput {
  governorate: string;
  area: string;
  address: string;
  notes?: string;
}

export interface OrderItem {
  id: string;
  productId: string;
  variantId?: string | null;
  productName: LocalizedText;
  image?: string;
  sku?: string;
  size?: string;
  color?: ProductColor;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface OrderEvent {
  status: OrderStatus;
  at: string;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId?: string | null;
  customerName: string;
  customerEmail?: string;
  phone: string;
  address: AddressInput;
  paymentMethod: PaymentMethod;
  status: OrderStatus;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  events: OrderEvent[];
  createdAt: string;
  updatedAt: string;
}

export interface CheckoutInput {
  customerName: string;
  email?: string;
  phone: string;
  address: AddressInput;
  paymentMethod: PaymentMethod;
  items: Array<{ productId: string; variantId: string | null; quantity: number }>;
  userId?: string | null;
}

export interface StoreSettings {
  storeName: LocalizedText;
  deliveryFee: number;
  freeDeliveryThreshold: number;
  phone: string;
  featuredProductIds: string[];
  updatedAt?: string;
}

export interface Promotion {
  id: string;
  code: string;
  title: LocalizedText;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  active: boolean;
  startsAt?: string | null;
  endsAt?: string | null;
}

export interface SizeOption {
  id: string;
  label: string;
  sortOrder: number;
  active: boolean;
}

export interface ColorOption extends ProductColor {
  id: string;
  active: boolean;
}
